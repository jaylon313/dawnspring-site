import io, json, glob, re, sys

raw = io.open('_work/en_source.tsv', encoding='utf-8').read().split('\n')
src = {}
for ln in raw:
    if not ln.strip():
        continue
    i, t = ln.split('\t', 1)
    src[int(i)] = t

lang = sys.argv[1] if len(sys.argv) > 1 else 'es'


def sig(s):
    return {
        'digits': tuple(re.findall(r'\d+(?:[.,]\d+)*', s)),
        'dot': '·' in s,
        'tag': tuple(re.findall(r'<[^>]+>', s)),
        'amp': '&amp;' in s,
    }


files = sorted(glob.glob('_work/%s_part*.json' % lang))
for p in files:
    tr = {int(k): v for k, v in json.load(io.open(p, encoding='utf-8')).items()}
    ids = sorted(tr)
    lo, hi = ids[0], ids[-1]
    print(p, 'ids', lo, '-', hi, 'count', len(ids))
    results = []
    for d in range(-2, 3):
        ok = 0
        n = 0
        for i in ids:
            j = i + d
            if j not in src:
                continue
            n += 1
            a, b = sig(src[j]), sig(tr[i])
            good = a['digits'] == b['digits'] and a['dot'] == b['dot'] and a['tag'] == b['tag'] and a['amp'] == b['amp']
            if good:
                ok += 1
        results.append((d, ok, n))
    print('   offset scores:', results)
