import io, json, glob, re, sys

raw = io.open('_work/en_source.tsv', encoding='utf-8').read().split('\n')
src = {}
for ln in raw:
    if not ln.strip():
        continue
    i, t = ln.split('\t', 1)
    src[int(i)] = t

lang = sys.argv[1] if len(sys.argv) > 1 else 'es'
tr = {}
for p in sorted(glob.glob('_work/%s_part*.json' % lang)):
    tr.update({int(k): v for k, v in json.load(io.open(p, encoding='utf-8')).items()})

problems = 0
for i in range(1042):
    e = src[i]
    t = tr.get(i)
    if t is None:
        print('MISSING', i, e[:60]); problems += 1; continue
    ed = re.findall(r'\d+(?:[.,]\d+)*', e)
    td = re.findall(r'\d+(?:[.,]\d+)*', t)
    if ed != td:
        print('DIGITS', i, ed, '->', td, '|', e[:60]); problems += 1
    if ('·' in e) != ('·' in t):
        print('DOT', i, '|', e[:60], '|', t[:60]); problems += 1
    if re.findall(r'<[^>]+>', e) != re.findall(r'<[^>]+>', t):
        print('TAG', i, '|', e[:60], '|', t[:60]); problems += 1
    if e.strip() == t.strip() and len(e) > 20:
        print('UNCHANGED', i, '|', e[:70]); problems += 1
print('---- problems:', problems, 'entries:', len(tr))
