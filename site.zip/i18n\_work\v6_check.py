import io, json, glob, re, sys
from collections import defaultdict

ix = json.load(io.open('_work/new_en_index.json', encoding='utf-8'))
todo = {}
for ln in io.open('_work/v6_todo.tsv', encoding='utf-8'):
    if ln.strip():
        i, t = ln.rstrip('\n').split('\t', 1)
        todo[i] = t

lang = sys.argv[1]
tr = {}
for p in sorted(glob.glob('_work/v6_%s_part*.json' % lang)):
    d = json.load(io.open(p, encoding='utf-8'))
    for k, v in d.items():
        if str(k) in tr:
            print('DUP id', k, 'in', p)
        tr[str(k)] = v

missing = [i for i in todo if i not in tr]
extra = [i for i in tr if i not in todo]
print('lang', lang, 'entries', len(tr), 'todo', len(todo))
print('MISSING', len(missing), missing)
print('EXTRA', len(extra), extra)

problems = 0
for i in todo:
    if i not in tr:
        continue
    e, t = todo[i], tr[i]
    ed = re.findall(r'\d+(?:[.,]\d+)*', e)
    td = re.findall(r'\d+(?:[.,]\d+)*', t)
    if ed != td:
        print('DIGITS', i, ed, '->', td, '|', e[:70]); problems += 1
    if re.findall(r'<[^>]+>', e) != re.findall(r'<[^>]+>', t):
        print('TAG', i, '|', e[:70], '|', t[:70]); problems += 1
    if not t.strip():
        print('EMPTY', i); problems += 1
    if re.search(r'&(?!amp;|lt;|gt;|quot;|#)', t):
        print('RAWAMP', i, t[:70]); problems += 1
    if ('·' in e) != ('·' in t):
        print('DOT', i, '|', e[:60], '|', t[:60]); problems += 1
print('problems:', problems)

# repeated English -> identical translation
groups = defaultdict(list)
for i, e in todo.items():
    groups[e].append(i)
bad = 0
for e, ids in groups.items():
    if len(ids) < 2 or any(i not in tr for i in ids):
        continue
    vals = {tr[i] for i in ids}
    if len(vals) > 1:
        bad += 1
        print('INCONSISTENT:', repr(e[:60]), ids, [tr[i][:40] for i in ids])
print('inconsistent groups:', bad)

# identical to English list (only allowed for numerals / brand tokens)
same = [(i, todo[i]) for i in todo if i in tr and tr[i] == todo[i]]
print('identical-to-EN entries:', len(same), same)
