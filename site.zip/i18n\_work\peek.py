import io, json, glob

raw = io.open('_work/en_source.tsv', encoding='utf-8').read().split('\n')
src = {}
for ln in raw:
    if not ln.strip():
        continue
    i, t = ln.split('\t', 1)
    src[int(i)] = t
es = {}
for p in sorted(glob.glob('_work/es_part*.json')):
    es.update({int(k): v for k, v in json.load(io.open(p, encoding='utf-8')).items()})

for token, esval in [('Home', 'Inicio'), ('All categories', 'Todas las categorías'),
                     ('Product category', 'Categoría de producto'),
                     ('Legal name', 'Nombre legal'),
                     ('Incoterm', 'Incoterm')]:
    sids = [i for i in range(1042) if src[i] == token]
    eids = [i for i in range(1042) if es.get(i) == esval]
    print(token, 'src:', sids)
    print('   es:', eids)
