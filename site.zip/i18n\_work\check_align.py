import io, json, glob, re, sys

raw = io.open('_work/en_source.tsv', encoding='utf-8').read().split('\n')
src = {}
for ln in raw:
    if not ln.strip():
        continue
    i, t = ln.split('\t', 1)
    src[int(i)] = t

lang = sys.argv[1] if len(sys.argv) > 1 else 'es'
tr = {}
for p in sorted(glob.glob('_work/%s_part*.json' % lang)):
    tr.update({int(k): v for k, v in json.load(io.open(p, encoding='utf-8')).items()})

lo = int(sys.argv[2]) if len(sys.argv) > 2 else 0
hi = int(sys.argv[3]) if len(sys.argv) > 3 else 1041

bad = []
for i in range(lo, hi + 1):
    e = src[i]
    l = tr.get(i)
    if l is None:
        bad.append((i, 'MISSING', e[:50], ''))
        continue
    r = len(l) / max(1, len(e))
    if not (0.55 <= r <= 1.9) or (('&amp;' in e) != ('&amp;' in l)) or (('·' in e) != ('·' in l)):
        bad.append((i, round(r, 2), e[:50], l[:50]))
print('suspect count', len(bad))
for b in bad:
    print(b)
