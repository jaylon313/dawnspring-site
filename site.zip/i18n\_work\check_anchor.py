"""Anchor check: invariant strings must live at exactly the same keys as en.json.

Usage: python check_anchor.py <lang> [<lang> ...]
"""
import json
import io
import os
import sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ANCHORS = [
    "Hainan Xiaoyuyuan International Trade Co., Ltd.",
    "info@example.com",
    "91460000MAK5PPE60T",
    "UN38.3",
    "xyy-lang",
    "XIAOYUYUAN",
]


def flat(obj, prefix=""):
    out = {}
    if isinstance(obj, dict):
        for k, v in obj.items():
            out.update(flat(v, prefix + "." + k))
    elif isinstance(obj, str):
        out[prefix] = obj
    return out


def load(name):
    with io.open(os.path.join(BASE, name), encoding="utf-8") as f:
        return json.load(f)


en = flat({k: load("en.json")[k] for k in ("shared", "pages")})
ok = True
for lang in sys.argv[1:]:
    tr = flat({k: load(lang + ".json")[k] for k in ("shared", "pages")})
    for anchor in ANCHORS:
        en_keys = {k for k in en if anchor in en[k]}
        tr_keys = {k for k in tr if anchor in tr[k]}
        if en_keys != tr_keys:
            ok = False
            short = lambda s: sorted(x.split(".")[-1] for x in s)
            print("[%s] MISALIGNED anchor %r" % (lang, anchor))
            print("   missing in translation:", short(en_keys - tr_keys)[:10])
            print("   extra in translation:  ", short(tr_keys - en_keys)[:10])
print("RESULT:", "PASS" if ok else "FAIL")
