import io, json, glob, re, sys

raw = io.open('_work/en_source.tsv', encoding='utf-8').read().split('\n')
src = {}
for ln in raw:
    if not ln.strip():
        continue
    i, t = ln.split('\t', 1)
    src[int(i)] = t

lang = sys.argv[1] if len(sys.argv) > 1 else 'pt'
tr = {}
for p in sorted(glob.glob('_work/%s_part*.json' % lang)):
    tr.update({int(k): v for k, v in json.load(io.open(p, encoding='utf-8')).items()})

# concept congruence: EN keyword -> required language keyword stem
CONCEPTS = {
    'es': {
        'certificate': 'certificad', 'documents': 'document', 'quotation': 'cotizaci',
        'sample': 'muestra', 'warranty': 'garant', 'battery': 'bater', 'supplier': 'proveedor',
        'tea': 'té', 'coffee': 'café', 'payment': 'pago', 'inspection': 'inspe',
        'delivery': 'entrega', 'price': 'precio', 'quality': 'calidad', 'module': 'módul',
        'inverter': 'inversor', 'solar': 'solar', 'tool': 'herramient', 'storage': 'almacenamiento',
        'company': 'empresa', 'address': 'direcci', 'language': 'idioma', 'privacy': 'privacidad',
        'compliance': 'cumplimiento', 'market': 'mercado', 'contract': 'contrat', 'origin': 'origen',
        'packaging': 'embalaje', 'grading': 'grado', 'harvest': 'cosecha', 'buyer': 'comprador',
        'freight': 'flete', 'customs': 'aduan', 'food': 'aliment', 'safety': 'seguridad',
        'capacity': 'capacidad', 'installation': 'instala', 'carrier': 'transportista',
        'unit': 'unidad', 'price list': 'lista de precios',
    },
    'pt': {
        'certificate': 'certificad', 'documents': 'document', 'quotation': 'cotação',
        'sample': 'amostra', 'warranty': 'garantia', 'battery': 'bateria', 'supplier': 'fornecedor',
        'tea': 'chá', 'coffee': 'café', 'payment': 'pagamento', 'inspection': 'inspeç',
        'delivery': 'entrega', 'price': 'preço', 'quality': 'qualidade', 'module': 'módulo',
        'inverter': 'inversor', 'solar': 'solar', 'tool': 'ferramenta', 'storage': 'armazenamento',
        'company': 'empresa', 'address': 'endereço', 'language': 'idioma', 'privacy': 'privacidade',
        'compliance': 'conformidade', 'market': 'mercado', 'origin': 'origem',
        'packaging': 'embalagem', 'grade': 'grau', 'harvest': 'colheita', 'buyer': 'comprador',
        'freight': 'frete', 'customs': 'aduaneir', 'food': 'aliment', 'safety': 'segurança',
        'capacity': 'capacidade', 'installation': 'instala', 'carrier': 'transportadora',
    },
}
CONCEPTS['pt']['price'] = 'preç'

cmap = CONCEPTS[lang]
bad = []
for i in sorted(tr):
    e = src[i].lower()
    t = tr[i].lower()
    for en, stem in cmap.items():
        if en in e and stem not in t:
            # allow English words legitimately kept
            bad.append((i, en, e[:60], t[:60]))
            break
print('mismatch count', len(bad))
for b in bad:
    print(b)
