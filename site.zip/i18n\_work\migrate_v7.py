"""Build a translation memory from v5 + v6 and re-apply it to the v7 English master.

Sources:
  _work/en_source.tsv            v5 id -> EN
  _work/<lang>_part*.json        v5 id -> translation (excludes v6_*)
  _work/new_en_index.json        v6 id -> {p, t}
  _work/v6_<lang>_part*.json     v6 id -> translation

Outputs:
  _work/v7_en_index.json         v7 id -> {p: [keys], t: EN}
  _work/v7_todo.tsv              id<TAB>EN for strings not found in the memory
  web/i18n/<lang>.json           v7 file with TM translations applied
"""
import io
import json
import os
import shutil

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WORK = os.path.join(BASE, "_work")
LANGS = ["id", "vi", "th", "ms", "fil", "es", "pt"]


def load(path):
    with io.open(path, encoding="utf-8") as f:
        return json.load(f)


def dump(path, obj):
    with io.open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)


def walk(obj, prefix=()):
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield from walk(v, prefix + (k,))
    elif isinstance(obj, str):
        yield prefix, obj


# v5 ids -> EN
v5_text = {}
with io.open(os.path.join(WORK, "en_source.tsv"), encoding="utf-8") as f:
    for line in f:
        line = line.rstrip("\n")
        if not line:
            continue
        ident, text = line.split("\t", 1)
        v5_text[ident] = text

# v6 ids -> EN
v6_index = load(os.path.join(WORK, "new_en_index.json"))


def build_memory(lang):
    mem = {}
    # v5 first (older), v6 wins on conflicts
    for name in sorted(os.listdir(WORK)):
        if name.startswith(lang + "_part") and name.endswith(".json"):
            for ident, tr in load(os.path.join(WORK, name)).items():
                src = v5_text.get(ident)
                if src and src not in mem:
                    mem[src] = tr
    for name in sorted(os.listdir(WORK)):
        if name.startswith("v6_" + lang + "_part") and name.endswith(".json"):
            for ident, tr in load(os.path.join(WORK, name)).items():
                entry = v6_index.get(ident)
                if entry:
                    mem[entry["t"]] = tr
    return mem


# v7 master
en_doc = load(os.path.join(BASE, "en.json"))
v7_paths = list(walk({k: en_doc[k] for k in ("shared", "pages")}))
v7_index = {str(i): {"p": list(p), "t": t} for i, (p, t) in enumerate(v7_paths)}
dump(os.path.join(WORK, "v7_en_index.json"), v7_index)

os.makedirs(os.path.join(WORK, "backup-v7"), exist_ok=True)

todo = set()
for lang in LANGS:
    mem = build_memory(lang)
    path = os.path.join(BASE, lang + ".json")
    shutil.copyfile(path, os.path.join(WORK, "backup-v7", lang + ".json"))
    doc = load(path)
    cur = {p: v for p, v in walk({k: doc[k] for k in ("shared", "pages")})}
    applied = 0
    for p, en_text in v7_paths:
        existing = cur.get(p)
        if existing is not None and existing not in (en_text,) and existing.strip():
            # already a non-English value (e.g. invariant translation) — keep
            if existing != en_text:
                continue
        tr = mem.get(en_text)
        if tr is not None:
            node = doc
            for part in p[:-1]:
                node = node[part]
            node[p[-1]] = tr
            applied += 1
        else:
            todo.add(en_text)
    dump(path, doc)
    print("%-4s memory-applied=%4d" % (lang, applied))

todo_rows = [(i, info["t"]) for i, info in v7_index.items() if info["t"] in todo]
with io.open(os.path.join(WORK, "v7_todo.tsv"), "w", encoding="utf-8", newline="\n") as f:
    for ident, text in todo_rows:
        f.write(ident + "\t" + text + "\n")
print("todo strings:", len(todo_rows))
