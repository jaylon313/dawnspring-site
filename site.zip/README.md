# 海南晓昱源国际贸易有限公司 — 独立站 v3（9 语言）

B2B 品牌展示 + 询盘获客站点。纯静态（HTML/CSS/JS），**无构建依赖、无付费依赖、无外部字体/CDN/图片请求**；语言版本为静态目录，可直接部署到任意静态托管，也可 `file://` 本地打开。

- 语言：**9 种，全部 complete** — English / 中文 / Bahasa Indonesia / Tiếng Việt / ไทย / Bahasa Melayu / Filipino / Español / Português
- 页面：15 类页面 × 9 语言（首页、关于、产品总览 + 5 品类、2 个主推方案、质量合规、市场服务、联系、隐私、404）
- 语言切换：右上角下拉框（原生 `<details>`，点击/键盘可用，普通链接，无 JS 依赖）
- 内容原则：不编造认证、客户、销量、工厂规模；缺失信息统一标 **TBD / 待补充**
- 站点规划见 [SITE-PLAN.md](SITE-PLAN.md)；联系方式唯一来源见 [../docs/contact-info.md](../docs/contact-info.md)；安全审计见 [../docs/security-audit.md](../docs/security-audit.md)

---

## 1. 目录结构

```
web/
├── index.html                    根入口：语言选择页（meta refresh → en/，另有 9 个链接）
├── about.html …                  其余根页面：极简跳转页 → en/<page>.html（浏览器/搜外链兜底）
├── 404.html                      根 404（英文完整页，托管平台使用）
├── _headers                      安全响应头（Cloudflare Pages / Netlify）
├── _redirects                    可选：平台级 301/302（见第 3.3 节）
├── robots.txt / sitemap.xml      爬虫规则 / sitemap 索引
├── sitemap-en.xml … sitemap-pt.xml   每种语言一个 sitemap（各 14 条 URL）
│
├── en/  zh/  id/  vi/  th/  ms/  fil/  es/  pt/
│   └── index.html … 404.html     15 个单语言静态页面（相对链接，资源用 ../assets/）
│
├── assets/
│   ├── css/style.css             全站样式（含语言下拉、pending 提示、响应式）
│   ├── css/chooser.css           根语言选择页样式
│   └── js/main.js                移动菜单、询盘表单占位、年份（已移除旧双语切换逻辑）
│
├── i18n/
│   ├── en.json                   完整英文文案（键值源）
│   ├── zh.json                   完整中文文案
│   ├── id.json / vi.json / th.json / ms.json / fil.json / es.json / pt.json
│   │                             骨架：键与 en.json 完全一致，值 = 英文原文占位
│   └── README.md                 翻译填充说明
│
└── _build/                       ★ 构建脚本与双语母版（不参与页面渲染，勿直接部署编辑）
    ├── build_i18n.py             从母版生成 9 语言页面 / i18n JSON / sitemap / 根跳转页
    ├── source/*.html             15 个中英双语母版（唯一手工编辑入口）
    └── check_i18n.py             多语言自检脚本
```

> `_build/` 与 `i18n/` 已在 `robots.txt` 中 `Disallow`，避免被搜索引擎收录。

---

## 2. 本地预览

### 方式 A：直接双击（无需服务器）
- 双击 `web/index.html` → 显示 9 语言选择页，并自动跳转到 `en/index.html`。
- 直接双击 `web/en/index.html`、`web/zh/index.html` 也可（站点无 fetch、无模块导入、无绝对路径）。
- 语言下拉为普通链接，`file://` 下同样可用。

### 方式 B：本地静态服务器（推荐）
```powershell
cd "D:\National Business\web"
python -m http.server 8080
```
打开 <http://127.0.0.1:8080/>（根入口会跳到 `/en/`）。
逐语言检查：<http://127.0.0.1:8080/en/>、`/zh/`、`/id/`、`/vi/`、`/th/`、`/ms/`、`/fil/`、`/es/`、`/pt/`。
停止：`Ctrl + C`。

### 方式 C：移动端
局域网访问 `http://<电脑IP>:8080/`，或浏览器 DevTools 设备模拟（390px 已验证无横向滚动）。

---

## 3. 部署

### 3.1 主方案：Cloudflare Pages（推荐）
1. 把 **`web/` 目录内的全部内容**（含 `en/`…`pt/`、`assets/`、`_headers`）上传/推送到 Cloudflare Pages。
2. 构建命令 **留空**，输出目录 **留空/根目录**。
3. 自定义域名绑定后自动 HTTPS。
4. 部署后验证：`curl.exe -sI https://<域名>/en/ | Select-String "content-security-policy|x-frame-options"`。
5. Sitemap：Search Console 提交 `https://<域名>/sitemap.xml`（索引文件，指向 9 个子 sitemap）。

### 3.2 备选：Netlify / Vercel
- **Netlify**：拖拽 `web/` 到 Netlify Drop；或 Git 连接，Publish directory = `web`，Build command 留空。`_headers` 直接生效。
- **Vercel**：Root Directory = `web`，Framework = Other，Build Command 留空；`_headers` 不生效，需改用 `vercel.json` 的 `headers` 字段（当前未创建）。

### 3.3 根路径跳转说明
- 根 `index.html` 为语言选择页（`meta refresh` 到 `en/`），根其余页面为 `noindex` 的跳转页，供 `file://` 和老外链兜底。
- 若希望服务器端 301（无闪烁、SEO 更干净），在 Cloudflare Pages 添加 `_redirects`：
  ```
  /            /en/            301
  /about.html  /en/about.html  301
  ```
  （其余页面同理；`_redirects` 当前未创建，避免与跳转页重复。）

### 3.4 上线前必须完成的 6 件事
1. **替换占位域名** `https://www.dawnspring-intl.com` → 正式域名（`build_i18n.py` 顶部 `DOMAIN` 常量，**必须重跑构建**，生成 canonical/hreflang/og:url/sitemap）。
2. **替换占位邮箱** `info@dawnspring-intl.com` → 正式企业邮箱（在 `_build/source/*.html` 中改，重跑构建）。
3. 补齐公司信息（注册号、地址、微信、社媒；电话 +86 139 1220 5995 已上线）。
4. 补充 `og:image` 与正式 Logo/favicon。
5. 提交 9 个 sitemap 至 Google/Bing。
6. 隐私政策 TBD 项（保存期限、跨境传输机制）经法务复核。

---

## 4. 多语言架构

### 4.1 方案（已选：静态目录 + hreflang）
- 每种语言一个目录：`/en/ /zh/ /id/ /vi/ /th/ /ms/ /fil/ /es/ /pt/`，同一文件名对应同一页面。
- 每页包含：`<html lang="…">`、canonical、9 条 `<link rel="alternate" hreflang>`（含 `x-default` → `/en/`）。
- 语言下拉：原生 `<details>/<summary>` + 链接列表，无 JS、无 fetch、键盘可达，链接指向**当前页面**的同语言版本。
- 内部链接全部为相对路径：同目录页面直接文件名，资源统一 `../assets/`，不串语言。
- 7 种未翻译语言：页面内容用英文占位，并在页首显示 "content pending" 提示；变量来源为 `i18n/<lang>.json` 骨架。

### 4.2 编辑与构建流程
1. 只编辑 `_build/source/*.html` 中的**中英双语母版**（`i18n-en` / `i18n-zh` 成对标记）。
2. 运行 `python _build/build_i18n.py`。
3. 脚本自动生成：9 个语言目录（135 个页面）、`i18n/*.json`、`sitemap*.xml`、根跳转页、根 404、9 语言 hreflang。
4. 运行 `python _build/check_i18n.py` 自检（0 error 才发布）。

### 4.3 翻译状态与重建（9/9 complete）

- `web/i18n/` 下 9 个 JSON 均为 `status=complete`：en/zh 由母版生成，id/vi/th/ms/fil/es/pt 由翻译交付后直接使用。
- 构建命令（从 JSON 渲染，不再用英文占位）：

```powershell
cd "D:\National Business\web"
python _build\build_i18n.py
python _build\check_i18n.py
python _build\check_structure.py
```

- 构建层统一处理裸 `&` → `&amp;`（实体引用不重复转义，`<em>` 等标签保持原样）。
- 修改译文：编辑 `i18n/<lang>.json` 的字符串值（保留键与 HTML 片段）→ 重跑构建。
- `python _build/build_i18n.py --refresh-en` 只重建 `en.json`（英文母版变更时使用），不会覆盖其他语言译文。
- 页头/页脚由「英文源串匹配已交付译文」渲染；后续如新增 nav/页脚文案，请同步在 `i18n/*.json` 增加对应译文（当前 nav 已全部本地化）。

### 4.4 SEO 注意
- hreflang 使用绝对 URL，域名替换后重跑构建；`x-default` 指向英文。
- 中文 hreflang 使用 `zh-Hans`；`<html lang>` 使用 `zh-CN`。
- 各语言页面 canonical 指向自身；根跳转页 `noindex`，避免与 `/en/` 重复。
- 未翻译语言虽为英文占位，但已带正确 `lang` 与 hreflang；正式推广前应先完成翻译，避免语言与内容不一致影响体验。

---

## 5. 安全与合规

- 安全响应头见 `_headers`；CSP 仅允许同源 CSS/JS + `data:` favicon + `mailto:` 表单，**禁止新增内联样式/脚本或第三方资源**。详见 `../docs/security-audit.md`。
- 询盘表单：`mailto:` 兜底 + JS 提示"表单待接入"，含必填隐私同意勾选，链接到 `privacy.html`；不会假装发送成功。
- 全站不宣称任何未取得的认证/资质/客户/销量；缺失项一律 TBD。
- 联系方式唯一来源：`../docs/contact-info.md`（电话 +86 139 1220 5995、邮箱 `info@dawnspring-intl.com` 占位、微信 TBD、WhatsApp 不启用）。

---

## 6. 维护清单

| 场景 | 操作 |
| --- | --- |
| 改文案/结构 | 编辑 `_build/source/*.html` → `python _build/build_i18n.py` → `python _build/check_i18n.py` |
| 换域名 | 改 `build_i18n.py` 顶部 `DOMAIN` → 重跑 → 更新 `robots.txt` |
| 接入表单后端 | 改 `_build/source/contact.html` 表单 → 重跑；同步更新隐私政策与 CSP `connect-src`/`form-action` |
| 新增页面 | 母版加入 `source/` → 在 `PAGES` 列表登记 → 在其它母版的导航/页脚加链接 → 重跑 |
| 新增语言 | 在 `LANGS` 增加语言 → `i18n/<code>.json` → 重跑（会自动加目录、hreflang、sitemap） |
| 检查 | `check_i18n.py`（页面/链接/hreflang/JSON 键一致性），`390px` 抽查 |

### 已知限制
1. 7 种语言的页面目前为英文占位（骨架 JSON 已备好），需翻译接入后重跑构建。
2. `_headers` 仅 Cloudflare Pages / Netlify 生效；Vercel 需 `vercel.json`。
3. 无统计/分析、无 CMS；改内容需走上述构建流程。
4. 占位图仍为 CSS/SVG 抽象图形，非产品实拍。
5. 隐私政策含 TBD 项，需法务复核。

---

## 7. 品牌与 Logo（v6）

- 品牌字标：**DAWNSPRING**；英文法定名：**Hainan Dawnspring International Trade Co., Ltd.**；中文法定名「海南晓昱源国际贸易有限公司」保持不变。
- 正式域名：`https://www.dawnspring-intl.com`；邮箱占位：`info@dawnspring-intl.com`（域名注册后替换）。

| 文件（web/assets/img/） | 用途 |
| --- | --- |
| `logo-horizontal-reverse.svg` | 深底页头/页脚横版（米白字 + DS 原标） |
| `logo-mark-reverse.svg` | 图形标（深底场景备用） |
| `logo-mark-512.png` | 社媒头像 / `apple-touch-icon` |
| `favicon.svg` | 浏览器标签 / 书签（16/32px 简化版） |
| `og.png` | 社交分享图 1200×630（每页 `og:image` / `twitter:image`） |

- Logo 源文件在 `brand/logo/original/`，站点使用的是发布副本；更换 Logo 时同时更新两处并重跑构建。
- 深色站点统一使用 **reverse** 横版；浅底物料（名片/信纸）使用 `logo-horizontal.svg`；单色印刷用 `-mono-*`。
- CSP 说明：Logo 为同源 SVG，`img-src 'self'` 已允许；无外部资源。
- 域名/邮箱替换位置：`_build/build_i18n.py` 顶部 `DOMAIN`、母版 `_build/source/*.html`、`i18n/*.json`、`robots.txt`、README/SITE-PLAN；改完重跑构建。
---

## 8. v6 信息架构（2026-11-06）

- 顶级导航精简为 4 项：**Home / Solutions / About / Contact**；移除 Featured、Quality & Compliance、Markets & Services（Featured 锚点会导致子页跳回首页的问题已修复）。
- 首页改为询盘优先：Hero（双 CTA）→ 业务板块（5 品类 + 2 主推高亮）→ Why us（源头直供/报价透明/文件可追溯/一站式多语）→ **首页内嵌询盘表单**（含文件需求多选 + 隐私同意）→ 信任条（全称/信用代码/9 语言/服务区域）→ 精简公司信息。
- 页面合并与旧 URL：`quality-compliance.html` → `about.html#quality`，`markets-services.html` → `solutions.html#markets`；9 个语言目录均生成 `noindex + meta refresh` 跳转页，sitemap 不再收录。
- 新增 `solutions.html` 业务方案总览页（5 品类 + 2 主推 + 目标市场/服务）。
- 5 个品类页新增左侧 sticky 子模块导航 + 子模块板块（适用场景 / 典型方案方向 / 需提供信息 / 询盘 CTA），移动端折叠为横向 chips。
- 页面数量：14 个正常页 + 2 个旧 URL 跳转页 × 9 语言 = 144 个语言页；`check_i18n.py`（含跳转页校验）与 `check_structure.py` 均 0 error。
- 增量翻译：v6 只更新 en/zh；其余 7 语言的变更页与页头页脚暂用英文占位，清单见 `web/_build/delta-report.md`。

### v6 追加（2026-11-06）

- 导航进一步精简为 3 项：**Home / Solutions / About**；右上角主按钮「Get a quote / 获取报价」滚动到首页询盘表单（`index.html#inquiry`）；登录式「Contact」不再出现在导航。
- `contact.html` 并入 `about.html#contact`（邮箱/电话/地址/信用代码/响应时效），旧 URL 与 quality/markets 一样为 `noindex + meta refresh`（9 语言均生成），sitemap 不收录。
- 新增 `feedback.html` 意见反馈页（只放页脚，不进主导航）：反馈类型、留言（必填）、邮箱（选填）、隐私同意（必填），mailto 兜底 + 「表单待接入」提示；注明仅内部处理、不公开、2 个工作日内回复；不提供公开评分/评价区。
- 信任替代物（About 页）：工作日 24 小时内响应询盘、样品政策、文件清单说明；首页信任条保留公司全称/信用代码/9 languages/服务区域。
- 页脚新增语言切换链接（9 种语言），并保留隐私政策 / 意见反馈 / 联系方式（About#contact）。
- 新增/变更键已写入 `web/_build/delta-report.md`（新增 55 / 变更 11）。
---

## 9. v7 文案通检与品类导航（2026-11-06）

- **命名**：导航与页面标题 Solutions → **Products & Solutions / 产品及方案**（文件名仍 `solutions.html`，避免断链）；breadcrumb、页脚与首页 CTA 同步。
- **品类页左侧导航**：改为常驻 sticky 两级导航——L1 五个品类（字号 15px，当前项高亮，点击切换页面）；L2 当前品类子模块锚点；原生 IntersectionObserver scrollspy 高亮当前子模块；sticky 顶部偏移与固定 header 对齐；删除右侧「其他品类/索取报价」小列表。移动端折叠为顶部横向 chips（两行，不遮挡正文）。
- **文案通检**：抽取全站 1059 条中英字符串逐句检查，修改 21 条（语法/搭配/术语/直译腔），清单见 `web/_build/copy-review.md`；典型：`about.span.112`「锂电池需承运人接受及危险品文件」→「锂电池需取得承运人认可，并随附危险品文件」。
- 重建 9 语言（14 正常页 + 3 跳转页 × 9 = 153 个页面），`check_i18n.py` / `check_structure.py` 0 error；9 语言首页 200；390px 无溢出。
- 增量翻译：`web/_build/delta-report.md` 已更新（新增 12 键、变更 370 键，主要是品类页/关于页文案与导航命名）。