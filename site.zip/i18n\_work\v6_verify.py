﻿import json, io, re
todo = []
for ln in io.open("_work/v6_todo.tsv", encoding="utf-8").read().split("\n"):
    if "\t" in ln:
        a,b = ln.split("\t",1); todo.append((a,b))
idx = json.load(io.open("_work/new_en_index.json", encoding="utf-8"))
def tags(s): return sorted(re.findall(r"</?[a-zA-Z][^>]*>", s))
def ents(s): return sorted(set(re.findall(r"&[a-zA-Z]+;", s)))
def nums(s): return sorted(re.findall(r"\d+(?:[.,]\d+)*", s))
for lang in ("id","vi"):
    doc = json.load(io.open(lang+".json", encoding="utf-8"))
    bad_tag=[]; bad_ent=[]; bad_num=[]
    for ident, en in todo:
        node = doc
        for p in idx[ident]["p"]: node = node[p]
        if tags(en)!=tags(node): bad_tag.append((ident,en[:50],node[:50]))
        elif ents(en)!=ents(node): bad_ent.append((ident,en[:50],node[:50]))
        elif nums(en)!=nums(node): bad_num.append((ident,nums(en),nums(node)))
    print("==",lang,"todo:",len(todo),"tag_bad:",len(bad_tag),"ent_bad:",len(bad_ent),"num_bad:",len(bad_num))
    for b in (bad_tag+bad_ent)[:6]: print("   ",b)
    for b in bad_num[:6]: print("   NUM",b)
