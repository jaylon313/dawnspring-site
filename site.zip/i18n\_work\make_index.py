"""Build web/i18n/_work/en_index.json: {id: {p: [path...], t: "English text"}}.

Every translatable string in en.json becomes one entry with a stable numeric id.
Translators produce {id: "translated text"}; apply.py merges it back.
"""
import json
import io
import os

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WORK = os.path.join(BASE, "_work")
os.makedirs(WORK, exist_ok=True)

with io.open(os.path.join(BASE, "en.json"), encoding="utf-8") as f:
    en = json.load(f)

out = {}
counter = [0]


def walk(value, path):
    if isinstance(value, dict):
        for k, v in value.items():
            walk(v, path + [k])
    elif isinstance(value, str):
        out[str(counter[0])] = {"p": path, "t": value}
        counter[0] += 1


for section in ("shared", "pages"):
    walk(en[section], [section])

with io.open(os.path.join(WORK, "en_index.json"), "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=1)

print("strings:", len(out))
print("chars:", sum(len(v["t"]) for v in out.values()))
