# -*- coding: utf-8 -*-
"""Multilingual self-check: pages, links, lang attrs, hreflang, dropdown, JSON keys."""
import json
import sys
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(r"D:\National Business\web")
LANGS = ["en", "zh", "id", "vi", "th", "ms", "fil", "es", "pt"]
sys.path.insert(0, str(Path(__file__).resolve().parent))
import build_i18n as mod  # noqa: E402
PAGES = list(mod.PAGES)
REDIRECTS = dict(mod.REDIRECTS)
BCP = {"en": "en", "zh": "zh-CN", "id": "id", "vi": "vi", "th": "th",
       "ms": "ms", "fil": "fil", "es": "es", "pt": "pt"}
VOID = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link",
        "meta", "param", "source", "track", "wbr"}
errors = []


class C(HTMLParser):
    def __init__(self, page):
        super().__init__(convert_charrefs=True)
        self.page = page
        self.attrs_html = {}
        self.anchors = []
        self.assets = []
        self.hreflang = []
        self.canonical = None
        self.langselect = 0
        self.lang_links = []
        self.inline_style = 0
        self.i18n_left = 0
        self.stack = []

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "html":
            self.attrs_html = a
        if "style" in a:
            self.inline_style += 1
        if tag == "a" and a.get("href"):
            self.anchors.append(a["href"])
        if tag in ("link", "img", "script") and (a.get("src") or a.get("href")):
            self.assets.append(a.get("src") or a.get("href"))
        if tag == "link" and a.get("rel") == "alternate" and a.get("hreflang"):
            self.hreflang.append(a["hreflang"])
        if tag == "link" and a.get("rel") == "canonical":
            self.canonical = a.get("href")
        if tag == "details" and "langselect" in (a.get("class") or ""):
            self.langselect += 1
        cls = a.get("class") or ""
        if "i18n-en" in cls or "i18n-zh" in cls:
            self.i18n_left += 1


def check_page(lang, slug):
    path = ROOT / lang / (slug + ".html")
    label = "%s/%s" % (lang, slug)
    if not path.exists():
        errors.append("missing page " + label)
        return
    text = path.read_text(encoding="utf-8")
    c = C(label)
    c.feed(text)
    c.close()
    if c.attrs_html.get("lang") != BCP[lang]:
        errors.append("%s: html lang=%r expected %s" % (label, c.attrs_html.get("lang"), BCP[lang]))
    if not c.canonical or "/%s/%s.html" % (lang, slug) not in c.canonical:
        errors.append("%s: bad canonical %r" % (label, c.canonical))
    if len(c.hreflang) != 10:
        errors.append("%s: hreflang links=%d expected 10" % (label, len(c.hreflang)))
    if c.langselect != 1:
        errors.append("%s: langselect count=%d" % (label, c.langselect))
    if c.i18n_left:
        errors.append("%s: %d i18n spans left" % (label, c.i18n_left))
    if c.inline_style:
        errors.append("%s: inline style x%d" % (label, c.inline_style))
    for href in c.anchors:
        if href.startswith(("mailto:", "tel:", "data:", "#")):
            continue
        if href.startswith(("http://", "https://")):
            errors.append("%s: absolute external anchor %s" % (label, href))
            continue
        target = (path.parent / href.split("#")[0]).resolve()
        if not target.exists():
            errors.append("%s: broken link %s" % (label, href))
    # language dropdown must contain all nine languages pointing to this page
    for code in LANGS:
        want = "../%s/%s.html" % (code, slug)
        if want not in text:
            errors.append("%s: dropdown link missing %s" % (label, want))


for lang in LANGS:
    for slug in PAGES:
        check_page(lang, slug)

# legacy URLs: noindex redirect pages, not normal pages
for lang in LANGS:
    for old_slug, (target, anchor) in REDIRECTS.items():
        p = ROOT / lang / (old_slug + ".html")
        label = "%s/%s (redirect)" % (lang, old_slug)
        if not p.exists():
            errors.append("missing redirect page " + label)
            continue
        txt = p.read_text(encoding="utf-8")
        if "noindex" not in txt or "http-equiv=\"refresh\"" not in txt:
            errors.append(label + ": not a noindex meta-refresh redirect")
        if "url=%s%s" % (target, anchor) not in txt:
            errors.append(label + ": redirect target wrong")
        if "/%s/%s%s" % (lang, target, anchor) not in txt:
            errors.append(label + ": canonical should point to target")

# json key parity + skeleton values
base = json.loads((ROOT / "i18n" / "en.json").read_text(encoding="utf-8"))
for code in LANGS:
    data = json.loads((ROOT / "i18n" / (code + ".json")).read_text(encoding="utf-8"))
    if data["language"] != code:
        errors.append("i18n/%s.json: wrong language field" % code)
    if set(data["pages"]) != set(base["pages"]):
        errors.append("i18n/%s.json: page set differs" % code)
    if list(data["shared"]) != list(base["shared"]):
        errors.append("i18n/%s.json: shared keys differ" % code)
    for slug in base["pages"]:
        if list(data["pages"][slug]["strings"]) != list(base["pages"][slug]["strings"]):
            errors.append("i18n/%s.json: %s keys differ" % (code, slug))
        if data["pages"][slug]["title"] is None:
            errors.append("i18n/%s.json: %s title empty" % (code, slug))
    # v6: 7 languages keep translations for unchanged pages and use English
    # placeholders for new/changed pages until the delta translation arrives.
    if code not in ("en", "zh") and data.get("status") != "complete":
        errors.append("i18n/%s.json: status should be complete" % code)

# sitemaps
for code in LANGS:
    sm = ROOT / ("sitemap-%s.xml" % code)
    if not sm.exists():
        errors.append("missing sitemap-%s.xml" % code)
    else:
        locs = sm.read_text(encoding="utf-8").count("<loc>")
        expected = len(PAGES) - 1  # 404 is not listed
        if locs != expected:
            errors.append("sitemap-%s.xml: %d urls expected %d" % (code, locs, expected))
index_sm = (ROOT / "sitemap.xml").read_text(encoding="utf-8")
for code in LANGS:
    if "sitemap-%s.xml" % code not in index_sm:
        errors.append("sitemap.xml missing sitemap-%s.xml" % code)

# root stubs + chooser (incl. legacy redirect stubs)
for slug in list(PAGES) + list(REDIRECTS):
    p = ROOT / (slug + ".html")
    if not p.exists():
        errors.append("missing root %s.html" % slug)
if "url=en/index.html" not in (ROOT / "index.html").read_text(encoding="utf-8"):
    errors.append("root index: no redirect to en/")

print("pages per language:", len(PAGES), "x", len(LANGS))
print("errors:", len(errors))
for e in errors[:80]:
    print("  ERROR", e)
sys.exit(1 if errors else 0)
