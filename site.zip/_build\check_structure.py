# -*- coding: utf-8 -*-
"""Structural check for all generated language pages."""
import sys
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(r"D:\National Business\web")
LANGS = ["en", "zh", "id", "vi", "th", "ms", "fil", "es", "pt"]
VOID = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link",
        "meta", "param", "source", "track", "wbr"}
errors = []


class C(HTMLParser):
    def __init__(self, name):
        super().__init__(convert_charrefs=False)
        self.name = name
        self.stack = []
        self.ids = []
        self.styles = 0
        self.inline_script = 0
        self.title = None
        self.in_title = False
        self.html_lang = None

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "html":
            self.html_lang = a.get("lang")
        if tag == "style":
            self.styles += 1
        if tag == "script" and not a.get("src"):
            self.inline_script += 1
        if "id" in a:
            self.ids.append(a["id"])
        if tag == "title":
            self.in_title = True
        if tag not in VOID:
            self.stack.append(tag)

    def handle_startendtag(self, tag, attrs):
        pass

    def handle_endtag(self, tag):
        if tag == "title":
            self.in_title = False
        if tag in VOID:
            return
        if not self.stack:
            errors.append("%s: stray </%s>" % (self.name, tag))
            return
        if self.stack[-1] != tag:
            if tag in self.stack:
                while self.stack and self.stack[-1] != tag:
                    errors.append("%s: unclosed <%s>" % (self.name, self.stack.pop()))
                if self.stack:
                    self.stack.pop()
            else:
                errors.append("%s: stray </%s>" % (self.name, tag))
        else:
            self.stack.pop()

    def handle_data(self, d):
        if self.in_title:
            self.title = (self.title or "") + d


count = 0
for lang in LANGS:
    for f in sorted((ROOT / lang).glob("*.html")):
        count += 1
        c = C("%s/%s" % (lang, f.name))
        c.feed(f.read_text(encoding="utf-8"))
        c.close()
        if c.stack:
            errors.append("%s: unclosed at EOF %s" % (c.name, c.stack))
        dup = {i for i in c.ids if c.ids.count(i) > 1}
        if dup:
            errors.append("%s: duplicate ids %s" % (c.name, sorted(dup)))
        if c.styles:
            errors.append("%s: inline <style> x%d (CSP)" % (c.name, c.styles))
        if c.inline_script:
            errors.append("%s: inline <script> x%d (CSP)" % (c.name, c.inline_script))
        if not c.title:
            errors.append("%s: missing title" % c.name)
        if c.html_lang is None:
            errors.append("%s: missing html lang" % c.name)
        if "data-title-en" in f.read_text(encoding="utf-8"):
            errors.append("%s: legacy data-title-en left" % c.name)

print("checked pages:", count)
print("errors:", len(errors))
for e in errors[:40]:
    print("  ERROR", e)
sys.exit(1 if errors else 0)
