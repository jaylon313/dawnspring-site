# Glosario ES — Hainan Dawnspring International Trade Co., Ltd.

Registro: español neutro internacional, B2B formal, trato de "usted".
Entidades HTML y etiquetas (`&amp;`, `<em>`, `<a href="…">`, `<span data-year>`) se conservan sin cambios.

| EN | ES | Nota |
|---|---|---|
| B2B | B2B | sigla internacional, sin traducir |
| inquiry | consulta | no "inquirir" |
| quotation / quote | cotización | escrito, con supuestos y vigencia |
| RFQ | solicitud de cotización | |
| MOQ (minimum order quantity) | MOQ (cantidad mínima de pedido) | sigla + aclaración la primera vez |
| lead time | plazo de entrega | |
| Incoterm | Incoterm | sin traducir |
| EXW / FOB / CIF | EXW / FOB / CIF | intactos |
| pre-shipment inspection | inspección previa al embarque | |
| certificate of origin | certificado de origen | |
| packing list | lista de empaque | neutro (evita "lista de empaquetado" regional) |
| commercial invoice | factura comercial | |
| freight forwarder | agente de carga | |
| consolidation | consolidación | de cargas/pedidos |
| supplier | proveedor | |
| specification / datasheet | especificación / ficha técnica | |
| test report | informe de ensayo | |
| compliance | cumplimiento | "Quality &amp; Compliance" → "Calidad y cumplimiento" |
| warranty | garantía | |
| energy storage (ESS) | almacenamiento de energía (ESS) | |
| C&amp;I (commercial &amp; industrial) | C&amp;I (comercial e industrial) | |
| hybrid inverter | inversor híbrido | |
| portable power station | estación de energía portátil | |
| BMS / EMS / PCS | BMS / EMS / PCS | siglas intactas |
| PV module | módulo fotovoltaico | |
| mounting structure | estructura de montaje | |
| grid code | código de red | |
| private label | marca blanca | |
| OEM / ODM | OEM / ODM | intactas |
| lot | lote | té/café |
| raw Pu'er (sheng) / ripe (shou) | Pu'er crudo (sheng) / maduro (shou) | |
| arabica green beans | granos verdes de arábica | |
| cupping | catación | |
| traceability | trazabilidad | |
| customs declaration | declaración aduanera | |
| business scope | objeto social | |
| credit code (Unified Social Credit Code) | código de crédito social unificado | |
| registered capital | capital registrado | |
| limited liability company | sociedad de responsabilidad limitada | |
| wholesaler | mayorista | |
| EPC contractor | contratista EPC | |
| end user | usuario final | |
| mini-grid developer | desarrollador de microrredes | |
| WeChat | WeChat | |
| B2B supply desk | mesa de suministro B2B | |
| DAWNSPRING / Dawnspring | DAWNSPRING / Dawnspring | marca intacta |
| Hainan Dawnspring International Trade Co., Ltd. | Hainan Dawnspring International Trade Co., Ltd. | nombre legal en inglés; primera aparición puede llevar "(comercio internacional)" si aporta claridad |
