import io, json, os, glob

data = {int(k): v for k, v in json.load(io.open('_work/pt_all.json', encoding='utf-8')).items()}
assert sorted(data) == list(range(1042)), len(data)

parts = [(0, 219), (220, 439), (440, 659), (660, 879), (880, 1041)]
for n, (lo, hi) in enumerate(parts, 1):
    path = '_work/pt_part%d.json' % n
    d = {str(i): data[i] for i in range(lo, hi + 1)}
    with io.open(path, 'w', encoding='utf-8') as f:
        json.dump(d, f, ensure_ascii=False, indent=1)
    print('wrote', path, len(d), lo, hi)
