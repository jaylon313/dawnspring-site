import io, json, re, sys
from collections import defaultdict

ix = json.load(io.open('_work/v7_en_index.json', encoding='utf-8'))
todo = []
for ln in io.open('_work/v7_todo.tsv', encoding='utf-8'):
    if ln.strip():
        i, t = ln.rstrip('\n').split('\t', 1)
        todo.append((i, t))

lang = sys.argv[1]
d = json.load(io.open('_work/v7_%s_part1.json' % lang, encoding='utf-8'))
d = {str(k): v for k, v in d.items()}
print('entries', len(d), 'todo', len(todo))
print('MISSING', [i for i, _ in todo if i not in d])
print('EXTRA', [i for i in d if i not in dict(todo)])

problems = 0
for i, e in todo:
    t = d.get(i, '')
    if not t.strip():
        print('EMPTY', i); problems += 1
    if re.findall(r'\d+(?:[.,]\d+)*', e) != re.findall(r'\d+(?:[.,]\d+)*', t):
        print('DIGITS', i, '|', e[:60], '|', t[:60]); problems += 1
    if re.findall(r'<[^>]+>', e) != re.findall(r'<[^>]+>', t):
        print('TAG', i, '|', e[:60], '|', t[:60]); problems += 1
    if re.search(r'&(?!amp;|lt;|gt;|quot;|#)', t):
        print('RAWAMP', i, t[:60]); problems += 1
    if t == e:
        print('SAME-AS-EN', i, repr(e)); problems += 1

# repeated English -> identical translation
g = defaultdict(list)
for i, e in todo:
    g[e].append(i)
for e, ids in g.items():
    if len(ids) > 1:
        vals = {d[i] for i in ids}
        if len(vals) > 1:
            print('INCONSISTENT', repr(e), ids); problems += 1
print('problems', problems)
