# SITE-PLAN — 海南晓昱源国际贸易有限公司 独立站 v1

> 状态：v6 已交付（导航精简为 4 项 + 首页询盘优先 + 页面合并跳转 + 品类页子模块；旧 URL 保留 noindex 跳转）
> 更新：2026-11-06
> 范围：本文件描述站点结构、文案大纲、SEO、设计方向、技术约束、假设与待确认项。

---

## 1. 定位与原则

| 项目 | 结论 |
| --- | --- |
| 商业定位 | B2B 品牌展示 + 询盘获客（lead generation），**不做在线支付/下单** |
| 目标客户 | 批发商 / 分销商、工程商（EPC）、安装商、贴牌品牌商、终端项目用户 |
| 目标市场 | 东南亚、欧洲、北美、拉美、非洲 |
| 主营品类 | 储能系统、光伏产品、五金工具、消费电子、云南茶叶与咖啡 |
| 语言 | 英文默认（EN）+ 中文（ZH）一键切换 |
| 公司阶段 | 0 起步：暂无进出口权、海关备案、外币账户 → 站点必须**如实披露**，不得暗示已具备 |
| 内容底线 | 不编造认证（CE/UL/FCC/UN38.3/ISO）、工厂、产能、销量、客户案例；缺失项一律 TBD / 待补充 |

### 1.1 需要 Lead 确认的关键决策
1. **英文公司名**：本方案采用 `Hainan Dawnspring International Trade Co., Ltd.`（"Dawnspring" 为"晓昱源"拼音，按中国企业英文名常见写法）。备选：`... International Trading Co., Ltd.`。最终名称建议以营业执照/对外经营备案上的英文名为准；若尚未备案，建议优先注册 `.com` 域名与英文名一致。
2. 是否公开 **注册地址** 与 **联系电话**（B2B 信任度显著相关，但涉及隐私）。
3. 是否在 v1 明确写出"进出口权办理中"（当前采用"not yet in place / 筹备中"的表述；如对外沟通策略不同可调整）。
4. 询盘邮箱：当前使用 `inquiry@dawnspring-intl.com` 占位，上线前必须替换为真实企业邮箱。

---

## 2. 信息架构与页面清单

所有页面位于 `web/` 根目录（扁平结构，`file://` 与静态托管均可直接访问）。

```
Home (index.html)
├── About (about.html)
├── Products (products.html)
│   ├── Energy Storage (energy-storage.html)
│   ├── Solar PV (solar-pv.html)
│   ├── Hardware & Tools (hardware-tools.html)
│   ├── Consumer Electronics (consumer-electronics.html)
│   └── Yunnan Tea & Coffee (tea-coffee.html)
├── Quality & Compliance (quality-compliance.html)
├── Markets & Services (markets-services.html)
├── Contact & Inquiry (contact.html)
├── Privacy Policy (privacy.html)
└── 404 (404.html)
```

| # | 页面 | 文件 | 主要作用 | 主 CTA |
| --- | --- | --- | --- | --- |
| 1 | 首页 | `index.html` | 定位、5 大品类、合作流程、真实状态声明 | 查看品类 / 发送询盘 |
| 2 | 关于我们 | `about.html` | 公司角色、"我们不是什么"、0→1 路线、公司信息表 | 联系我们 |
| 3 | 产品总览 | `products.html` | 5 品类入口、品类对比表、报价所需信息 | 索取报价 |
| 4 | 储能系统 | `energy-storage.html` | 户用/工商业/便携、选型清单、电池运输文件说明 | 索取报价 |
| 5 | 光伏产品 | `solar-pv.html` | 组件/支架/逆变器/BOS、并网与检测文件说明 | 索取报价 |
| 6 | 五金工具 | `hardware-tools.html` | 工具/配件/紧固件/耗材/组套、标准与包装 | 索取报价 |
| 7 | 消费电子 | `consumer-electronics.html` | 充电器/线缆/小家电/贴牌、目的国合规 | 索取报价 |
| 8 | 云南茶叶咖啡 | `tea-coffee.html` | 普洱/绿茶/红茶/咖啡豆、批次与食品文件 | 索取报价 |
| 9 | 质量与合规 | `quality-compliance.html` | 质检流程、认证状态表、核实方法、"我们不会做" | 咨询文件 |
| 10 | 市场与服务 | `markets-services.html` | 5 大区域、服务范围与状态、贸易术语/付款/物流 | 沟通市场 |
| 11 | 联系与询盘 | `contact.html` | 询盘表单（占位）、联系方式、回复说明 | 提交/邮件 |
| 12 | 主推：户用光储充 | `solution-solar-storage-ev.html` | 系统组成、方向性配置、目标市场、选型清单、交付边界 | 索取选型表 |
| 13 | 主推：云南茶咖 | `solution-yunnan-tea-coffee.html` | 产区、品类等级、可索取文件（TBD）、样品/MOQ/贴牌 | 索取样品 |
| 14 | 隐私政策 | `privacy.html` | 数据收集范围、用途、保存期限、第三方、用户权利、Cookie/localStorage | 联系删除/更正 |
| 15 | 404 | `404.html` | 兜底导航 | 返回首页 |

导航（顶部）：Home / About / Products / Quality & Compliance / Markets & Services / Contact + 语言切换 + `Get a quote`。
页脚：品牌简介 + 产品链接 + 公司链接（含隐私政策）+ 联系方式（电话 +86 139 1220 5995 / 邮箱占位 / 微信 TBD）+ 版权与免责声明。

---

## 3. 中英文案大纲

> 实现方式：同一 HTML 中并列 `<span class="i18n-en">` / `<span class="i18n-zh">`，CSS 按 `html[data-lang]` 显隐，JS 仅切换属性并记忆（localStorage）。**不使用 fetch / JSON**，双击 `file://` 即可切换。

### 3.1 首页
- Hero
  - EN：*A practical China supply partner for energy storage, solar and everyday goods.*
  - ZH：*面向全球买家的中国供应链伙伴：储能、光伏与日用产品。*
  - 副标题：海南起步阶段贸易公司；覆盖 5 大品类、5 个目标区域；如实说明进展。
  - CTA：Explore product categories / Send an inquiry；标签：B2B only — no online checkout、5 categories、EN/中文。
- 主营品类（5 卡 + "不确定属于哪类"卡）
- 合作流程 4 步：Inquiry → Sourcing & clarification → Quotation & sample → Fulfilment & documents
- 工作原则 4 条：先规格后报价、多品类整合、双语沟通、单证透明
- **真实状态声明**（进出口权/海关备案/外币账户尚未具备；认证按产品逐项确认）
- 公司信息表（法律名称、注册地、经营模式、资质 TBD、地址电话 TBD）
- CTA 区 + 页脚免责声明

### 3.2 关于我们
- "A new trading company, stated plainly."（新公司，如实说明）
- 我们的角色：规格与工厂之间的协调者（采购、比价、单证、单一双语对接人）
- 公司信息表（注册号/成立时间/地址/团队规模/TBD；进出口权、海关备案、外币账户 = 未取得）
- **What we are not**：不是制造商 / 尚未取得认证 / 不是网店 / 进出口权待办理
- 0→1 路线图：Phase 1 品牌与供应商地图（now）→ Phase 2 贸易资质 → Phase 3 首批参考订单（日期 TBD）
- CTA：小批量试单

### 3.3 产品总览
- "Five categories we can source, quote and consolidate."
- 5 品类卡（含示意图占位）
- 品类对比表：品类 / 典型买家 / 报价所需材料 / 文件状态（TBD）
- 报价规范：口径（型号、规格、包装、Incoterm、目的港、有效期）
- 报价所需 6 项 + 我方返回内容
- 不公布固定 MOQ/价格/交期的原因说明

### 3.4 品类页（5 页统一结构）
1. Hero：一句话定位 + 标签（细分范围 / 认证状态 / 文件 TBD）
2. Scope：品类范围 + **重要限制**（不拥有工厂，认证仍在核实）
3. 产品系列（5–6 卡）：名称 + 用途说明
4. 报价所需信息清单（每类 8 项，可执行）
5. 报价要点表：Incoterm / Payment / Validity / Inspection / Documents
6. 相关品类 + 询盘 CTA

各品类差异化要点：
- **储能**：负载曲线、备电时长、相数/电压、并离网；UN38.3/MSDS 由电池厂出具，危险品运输说明。
- **光伏**：kWp、屋顶/地面、逆变器类型、目的国并网标准、IEC 61215/61730 报告要求。
- **五金**：材质/热处理/表面处理/公差/执行标准/包装；性能宣称须有测试数据。
- **消费电子**：目的国认证（CE/UKCA/FCC/RoHS/REACH 等）、插头/电压/包装语言、贴牌与 IP 审核。
- **茶叶咖啡**：品类等级、产季、加工方式、包装、食品安全与植检文件由进口商核实；不宣称有机/地理标志。

### 3.5 质量与合规
- 质检流程 4 步：供应商文件审核 → 样品与规格核对 → 出货前验货 → 文件包
- **认证状态表**：CE、UKCA、UL/ETL、FCC、UN38.3、IEC 61215/61730、RoHS/REACH、ISO 9001、ISO 22000/HACCP；"出具方 + 本站状态 = TBD / not claimed"
- 核实证书 6 步法（编号、型号、持证人、有效期、官网数据库、完整报告）
- 四项承诺：不伪造证书 / 不修改报告 / 不盗用工厂照片 / 不编造案例

### 3.6 市场与服务
- 5 区域卡：东南亚、欧洲、北美、拉美、非洲（市场特点 + 买家类型 + 合作伙伴 TBD）
- 服务与状态表：报价（可用）、样品（可用）、拼柜（可行性 TBD）、验货（机构 TBD）、出口单证（合作方 TBD）、收款（暂不可用）、OEM/ODM（TBD）
- 付款 / Incoterms / 物流说明（含锂电池危险品）
- 贸易资质状态声明

### 3.7 联系与询盘
- 表单字段：姓名\*、公司、邮箱\*、电话、国家\*、品类\*、数量、需求\*、同意条款\*
- 表单状态：`action="mailto:inquiry@dawnspring-intl.com"` + JS 拦截，提交即提示 **"表单待接入 / Form pending integration"** 并给出邮件替代方案（不静默失败）
- 侧栏：邮箱/电话/地址/社媒（TBD）、语言、回复目标（2 个工作日，UTC+8）
- 发送前提示：暂不支持附件，可邮件附送

---

## 4. SEO 方案

### 4.1 关键词地图

| 页面 | 核心词（EN） | 长尾/意图词 | 中文关键词 |
| --- | --- | --- | --- |
| 首页 | China B2B trading company, energy storage supplier China | sourcing partner China, wholesale solar storage supplier | 中国 储能 供应商, B2B 采购 中国 |
| 关于 | Hainan trading company, China export partner | new trading company transparency | 海南 国际贸易公司 |
| 产品总览 | energy storage solar hardware supplier | B2B product sourcing China | 储能 光伏 五金 批发 |
| 储能 | home battery storage supplier China, commercial energy storage B2B | 5kWh 10kWh home battery wholesale, C&I ESS supplier | 户用储能 批发, 工商业储能 供应商 |
| 光伏 | solar panel supplier China B2B, solar mounting structure | PV module wholesale, hybrid inverter supplier | 光伏组件 批发, 光伏支架 |
| 五金 | hand tools wholesale China, hardware tools supplier | power tool accessories wholesale, tool kit OEM | 五金工具 批发, 工具组套 |
| 消费电子 | consumer electronics supplier China, charger wholesale | private label charger manufacturer, USB cable wholesale | 消费电子 批发, 充电器 贴牌 |
| 茶叶咖啡 | Yunnan tea wholesale, Yunnan coffee beans supplier | Pu'er tea wholesale, arabica coffee green beans | 云南茶叶 批发, 云南咖啡豆 |
| 质量合规 | product certification China exporter, TBD certificate status | CE UN38.3 documentation | 产品认证 说明 |
| 市场服务 | export to Southeast Asia Europe logistics | Incoterms FOB CIF China supplier | 出口 东南亚 欧洲 物流 |
| 联系 | B2B inquiry China supplier, request quotation | send RFQ China | 询盘, 报价申请 |

### 4.2 已实现
- 每页独立 `title`、`meta description`、`og:title/description/type/site_name/locale/url`、`twitter:card`、`theme-color`
- 语义化结构：`header/nav/main/section/article/aside/footer`、`h1` 唯一、表格 `caption`/`scope`、`aria-current="page"`
- 面包屑（视觉 + `aria-label`）、跳过链接、可见焦点、`alt/aria-label` 占位说明
- `robots.txt` + `sitemap.xml`（占位域名 `dawnspring-intl.com`，上线必须替换）
- 内部链接扁平化、描述性锚文本
- 无外部字体/CDN/图片请求 → 首屏极快、无第三方追踪

### 4.3 上线后待办
1. 将 `https://www.dawnspring-intl.com` 批量替换为正式域名（canonical / og:url / sitemap）。
2. 补充 `og:image`（1200×630）与 `Logo` 文件；当前故意省略，避免破图。
3. 若做双语独立 URL（`/en/`、`/zh/`），需增加 `hreflang` 并拆分页面；v1 为单 URL + 前端切换，**不做 hreflang**（避免错误标注）。
4. 接入 Google Search Console / Bing Webmaster，提交 sitemap。
5. 建议后续增加：Organization / Product JSON-LD（需真实公司信息与产品数据后再加，避免结构化数据造假）。
6. 内容增长：按品类写选型指南/采购 FAQ（每篇 800–1200 词），不要批量 AI 填充页。

---

## 5. 设计方向

| 维度 | 决定 |
| --- | --- |
| 气质 | 工业、克制、可信；接近设备制造商/工程公司的技术手册感，而非消费品牌 |
| 主色 | 近黑 `#0a0d10` / 炭灰 `#11161c` / 描边 `#232d38` |
| 强调色 | 黄铜金 `#c8a35a`（用于 kicker、按钮、关键线） |
| 辅助色 | 钢蓝 `#8fb3c7`、成功绿 `#7fbf9a`、警示琥珀 `#d9a441`（TBD 标记） |
| 字体 | 系统字体栈（无外链字体）：Segoe UI / Helvetica / Noto Sans SC / 微软雅黑；等宽用于编号、标签、技术标注 |
| 图形 | 全部内联 SVG / CSS 渐变 / 网格纹理；无图库照片、无 CDN 图片 |
| 组件 | 卡片、kicker、标签、步骤条、对比表、note、CTA band、双语切换、汉堡菜单 |
| 布局 | 12 栅容器 `max-width:1160px`；桌面 3 列 / 平板 2 列 / 手机 1 列；断点 1024 / 900 / 640 / 420 |
| 可访问性 | 对比度 ≥ 4.5:1（正文）、跳转链接、键盘可达、`:focus-visible`、`prefers-reduced-motion`、语义标签、表格 caption |
| 诚实可视化 | 占位图统一角标 "SVG/CSS placeholder"；页脚声明"所有视觉为示意图，非产品实拍" |

### 5.1 设计取舍说明
- 不放大数字、不用"全球领先/10 年经验"等空话；用表格、清单、TBD 标签建立可信度。
- 深色系在工业 B2B 中显专业，但需保证长文可读性 → 正文 `#a3aeba` 于 `#0a0d10` 约 6.5:1。
- 手机端优先保证：导航可用、表格横向滚动、按钮 ≥ 44px、表单单列。

---

## 6. 技术实现

| 项 | 方案 |
| --- | --- |
| 技术栈 | 纯 HTML + CSS + 原生 JS（单文件 `assets/js/main.js`），零依赖、零构建 |
| 双语 | 并列 `i18n-en` / `i18n-zh` 标记 + CSS 显隐；`<html data-lang>`；切换写入 localStorage；支持 `?lang=zh`；同步 `<html lang>`、`document.title`、meta description |
| 导航 | 桌面水平导航；≤900px 汉堡菜单（`aria-expanded`，Esc 关闭，点击外部关闭） |
| 询盘 | `<form action="mailto:...">` 兜底 + JS 拦截提示"表单待接入"；无后端、无第三方表单服务 |
| 兼容 | 支持 `file://` 直开；无 fetch、无模块 import、无绝对路径 |
| 性能 | 无外部请求；CSS/JS 合计约 30KB；无字体下载 |
| 部署 | 任意静态托管（Cloudflare Pages 为主，见 README） |

---

## 7. 假设与待确认项

### 7.1 已做的假设
1. 中文公司名与"晓昱源"拼音对应；英文名按常见贸易公司写法拟定（需法务/工商口径确认）。
2. 公司已完成工商注册（成立时间/注册号/地址未提供 → 全部 TBD）。
3. 询盘主渠道为企业邮箱（占位 `info@dawnspring-intl.com`，上线前替换）；电话 +86 139 1220 5995 已公开；微信待补充；WhatsApp 因大陆使用不稳定，v2 起不采用。
4. 暂不展示真实产品图（尚无素材）→ 一律 CSS/SVG 占位并明示。
5. 不设价格、MOQ、交期 → 一律"逐单报价"。
6. 不做账号、购物车、支付、物流查询。
7. 网站语言为 EN 默认；未做独立中文 URL 与 hreflang。

### 7.2 待公司提供（优先顺序）
| 优先级 | 素材 | 用途 |
| --- | --- | --- |
| P0 | 正式域名 + 企业邮箱 | 上线、替换 `dawnspring-intl.com`、表单收件 |
| P0 | 公司注册信息（注册号、成立日期、注册地址） | 关于页/页脚，建立信任 |
| P0 | 微信 / 社媒账号（电话 +86 139 1220 5995 已上线） | 联系页与页脚 |
| P1 | Logo（SVG + PNG） | 页头/页脚/favicon |
| P1 | 产品实拍或供应商授权图（每品类 3–6 张） | 替换占位图；需书面授权 |
| P1 | 各品类主推型号与规格书 | 品类页示例型号、报价口径 |
| P2 | 已取得的证书扫描件（如有） | 合规页"已核实"状态更新 |
| P2 | 贸易资质办理时间表 | 路线图日期、市场页状态 |
| P2 | 社媒账号（LinkedIn/Facebook/WhatsApp Business） | 页脚与联系页 |
| P2 | 中文公司简介正式版（300/800 字） | 关于页文案润色 |
| P3 | 隐私政策/使用条款 | 若后续接入表单后端或统计 |
| P3 | 客户案例（真实、可授权） | 上线 3–6 个月后再启用 |

### 7.3 已知风险与合规提醒
- 若未来取得进出口权/认证，需同步更新 `about.html`、`quality-compliance.html`、`markets-services.html`、页脚声明，避免与旧表述冲突。
- 产品图/工厂图若来自供应商，必须取得书面授权，否则可能侵权。
- 茶叶/咖啡涉及食品进口法规，站点已提示"进口商负责目的国合规"，不可改为"我们保证清关"。
- 收款路径未定前，任何报价/页面都不得出现"支持 T/T、信用证"等具体收款承诺（当前未写）。
- 跟踪统计（如接入）需先补隐私政策与 Cookie 提示。

---

## 8. v1 验收对照

| 验收项 | 状态 |
| --- | --- |
| 15 个页面（含 2 个主推落地页、隐私政策、404）可访问、内部链接无 404 | ✅ 构建期链接/元数据自检 0 error（自检脚本未随站点交付） |
| EN 默认 + 右上角中英切换，`file://` 直接可用 | ✅ 无 fetch，localStorage + `?lang=` |
| 响应式 手机/平板/桌面 | ✅ 断点 1024/900/640/420（浏览器截图复核） |
| 每页 title/description/OG | ✅ 12/12 |
| 语义化 + 基本可访问性 | ✅ skip link、aria、对比度、键盘导航 |
| 占位图（无盗图） | ✅ 全部 CSS/SVG 并标注 |
| 表单静态方案 + 页面注明"待接入" | ✅ mailto 兜底 + JS 提示 |
| 不编造认证/客户/销量/工厂 | ✅ 全文 TBD 化，含"我们不是什么"章节 |
| README 部署说明 + 素材清单 | ✅ |

---

## 9. 后续版本建议（v1.1 →）
1. 接入真实表单后端（Cloudflare Worker + 邮件转发 或 Netlify Forms），保留双语文案与"已发送"成功态。
2. 增加 `og:image`、favicon 多尺寸、`manifest`。
3. 补充 2–3 篇品类选型长文（储能容量计算、光伏并网文件、工具标准对照）。
4. 接入 Search Console 与基础隐私友好统计（Plausible/Umami 自托管）。
5. 若进入欧盟市场，评估 GDPR 与 Cookie 合规。

---

## 10. v2 变更（2026-11-06）

| 变更 | 内容 | 文件 |
| --- | --- | --- |
| 隐私政策 | 新增中英双语 `privacy.html`：数据类别、用途、保存期限（24 个月目标值，最终 TBD）、第三方（无统计/无广告）、Cookie 与 localStorage（仅 `xyy-lang`）、用户权利、跨境传输（TBD）、泄露/变更说明；页脚、联系页、sitemap 均可到达 | `privacy.html`、全部页脚、`sitemap.xml` |
| 表单同意 | 询盘表单隐私同意勾选保持必填，新增隐私政策链接与说明；表单仍为 mailto 兜底 + "待接入"提示，不假装发送 | `contact.html`、`assets/css/style.css` |
| 联系方式 | 电话 +86 139 1220 5995 全站上线（`tel:` 链接）；邮箱统一为 `info@dawnspring-intl.com` 占位；微信 TBD；WhatsApp 从全站移除；联系方式集中到 `docs/contact-info.md` | 全部页面、docs |
| 安全加固 | 新增 `_headers`（CSP 最小权限、nosniff、DENY、Referrer-Policy、Permissions-Policy、COOP/CORP、XSS 关闭）；移除全部内联 `style`/内联脚本；无第三方资源；`docs/security-audit.md` 逐项审计与运营侧清单 | `_headers`、`assets/css/style.css`、`docs/security-audit.md` |
| 响应式修正 | 导航折叠断点由 900px 提前到 1120px，避免 901–1046px 区间导航溢出；CSS 补齐 `min-width:0` 与表格容器滚动 | `assets/css/style.css`、`assets/js/main.js` |
| 可选配图 | 本次时间盒内未引入免费图库图片（需逐张核实 CC0/公有领域并记录授权），保留 CSS/SVG 占位与 "illustrative" 标注 | — |
## 11. v2.1 变更（主推方案，2026-11-06）

- 首页 `#featured` 区块（五品类之前）+ 导航 `Featured` + 产品总览顶部入口 + 页脚两条主推链接。
- `solution-solar-storage-ev.html`：户用光储充一体。系统 6 部件、5/10/15 kWh × 3/5/6 kW × 7/11/22 kW 方向性配置（230 V/400 V 市场差异）、目标市场 菲/越/印尼 + 巴西/智利、选型所需信息、交付与本地安装边界；认证/质保/TBD。
- `solution-yunnan-tea-coffee.html`：云南茶咖。四产区（保山/普洱/临沧/德宏）、品类与等级工艺、可索取文件表（全部 TBD）、样品/MOQ/贴牌选项、进口合规责任说明；不作有机/地理标志宣称。
- 两个落地页均进入 `sitemap.xml`、页脚与全站导航（`index.html#featured` 锚点）。
---

## 12. 多语言架构（v3，2026-11-06）

### 12.1 方案

| 维度 | 决定 |
| --- | --- |
| 架构 | **每语言静态目录**：`/en/ /zh/ /id/ /vi/ /th/ /ms/ /fil/ /es/ /pt/`，每种语言 15 个页面（共 135 页） |
| 语言选择 | 页头右上角原生 `<details>` 下拉（点击/键盘可达、普通链接、无 JS、无 fetch、`file://` 可用），链接保留当前页面路径 |
| 语言标注 | 每页 `<html lang>`（zh 用 `zh-CN`，其余用 ISO 码；中文 hreflang 用 `zh-Hans`） |
| SEO | 每页 canonical 指向自身；9 条 `hreflang` 交替链接 + `x-default` → `/en/`；`sitemap.xml` 为索引，指向 9 个 `sitemap-<lang>.xml` |
| 根路径 | `/` 为语言选择页（meta refresh → `/en/`，另列 9 个链接）；其余根页面为 `noindex` 跳转页，兜底 `file://` 与老外链；根 `404.html` 为英文完整页 |
| 资源路径 | 语言页统一 `../assets/…`、`../<lang>/<page>.html`；同语言内页面互链只用文件名，不串语言 |
| 构建 | `web/_build/build_i18n.py`：从 `_build/source/*.html` 双语母版生成全部语言页面、JSON、sitemap、跳转页 |
| 自检 | `web/_build/check_i18n.py`：9×15 页链接、lang/canonical/hreflang、下拉 9 链接、JSON 键一致性，0 error |

### 12.2 语言与状态

| 代码 | 语言 | 状态 | 页面内容 | JSON |
| --- | --- | --- | --- | --- |
| en | English | ✅ 完整 | 英文 | `i18n/en.json` 完整 |
| zh | 中文 | ✅ 完整 | 中文 | `i18n/zh.json` 完整 |
| id | Bahasa Indonesia | ✅ 完整 | 译文 | `i18n/id.json` 完整 |
| vi | Tiếng Việt | 🟡 骨架 | 同上 | `i18n/vi.json` |
| th | ไทย | 🟡 骨架 | 同上 | `i18n/th.json` |
| ms | Bahasa Melayu | 🟡 骨架 | 同上 | `i18n/ms.json` |
| fil | Filipino | 🟡 骨架 | 同上 | `i18n/fil.json` |
| es | Español | 🟡 骨架 | 同上 | `i18n/es.json` |
| pt | Português | 🟡 骨架 | 同上 | `i18n/pt.json` |

> 7 种骨架语言**没有机翻**：页面显示英文原文并在页首标注 "content pending"，JSON 值与 EN 一致，等待翻译人员/翻译 agent 填充后重跑构建。

### 12.3 翻译交付与重建（2026-11-06）

1. 7 种语言（id/vi/th/ms/fil/es/pt）译文已由翻译 agent 交付到 `web/i18n/*.json`，`status=complete`，键集合与 `en.json` 一致。
2. 构建脚本 `build_i18n.py` 已改为**从交付后的 JSON 渲染**：不再用英文母版填充 7 语言页面；`--refresh-en` 仅用于重建 `en.json`（默认保留全部译文）。
3. 构建时统一做「裸 `&` → `&amp;`」转义（实体引用节点单独保留，避免双重转义与标签损坏）。
4. 重建命令：

```powershell
cd "D:\National Business\web"
python _build\build_i18n.py
python _build\check_i18n.py
python _build\check_structure.py
```

5. 语言页头/页脚说明：早期 JSON 的 `shared` 键在 header/footer 之间存在命名冲突，翻译交付中不含 nav/CTA 文案；构建层改为「以英文源串匹配已交付译文」渲染 header/footer，nav、CTA、页脚均已本地化（`Featured` 取 `Featured:` 译文的词首、`Get a quote` 复用 `Request a quotation` 译文），仅无障碍跳过链接保留英文。
6. 验收：135 页重建，`check_i18n.py` / `check_structure.py` 0 error；es/pt/th/vi/id/ms/fil 的首页、privacy、solution 页 HTTP 200；390px 无横向溢出。

### 12.4 与 v2.1 的差异

- 根页面不再直接展示双语内容：双语母版移入 `_build/source/`，线上为单语言静态页。
- 原 JS 双语切换（`data-set-lang` + localStorage）仅保留给母版调试；线上切换靠链接，CSP 与 `file://` 均无依赖。
- 导航新增语言下拉，原 `EN / 中文` 切换按钮被替换。
---

## 13. v4 变更（文案收敛 + 工商信息 + 表单，2026-11-06）

### 13.1 文案收敛

- 删除全站反复出现的「start-up phase / 尚未取得进出口权 / 我们不做工厂 / TBD」式表述；产品页与解决方案页的免责段替换为中性的「文件与认证按供应商与订单确认」一句。
- 资质与边界集中到两处：`quality-compliance.html` 的 **Our status** 区块（`#our-status`）+ 页脚一行（含 Our status 链接）；About 页保留工商信息与经营范围摘要。
- 语气转为正向：sourcing / consolidation / export documentation / customs & inspection coordination / multilingual communication。
- 保留必要披露：不宣称未取得的认证、客户案例、销量、工厂规模；认证状态表仅存在于质量与合规页。

### 13.2 工商信息上线（据营业执照）

- 统一社会信用代码 91460000MAK5PPE60T；类型 有限责任公司（自然人投资或控股）；成立 2026-01-06；注册资本 100 万元人民币；住所 海南省海口市美兰区蓝天街道大英山东三路3号海阔天空国兴城一期（B16地块）15#号楼17层15-2-1701A房。
- 经营范围摘要：货物进出口；技术进出口；进出口代理；国内贸易代理；报关业务；报检业务；电池及零配件；新能源汽车电附件；五金批发零售；建筑材料；农副产品；食品经营（许可项目）。
- 落位：页脚（全称 + 信用代码 + ©）、About（工商信息表 + 经营范围摘要 + 服务四项）、Contact（地址 + 信用代码）、Quality 页 Our status、Privacy 页通信地址、首页公司信息表。
- 联系方式唯一来源更新：`docs/contact-info.md`。

### 13.3 询盘表单

- 新增「需要随附的文件 / Documents requested」多选（非必填）：CE、UL、UN38.3、FDA、产地证、卫生证、检测报告、其他、暂不需要。隐私同意保持必填；mailto 兜底与「表单待接入」提示不变。

### 13.4 其他修复

- 两个主推方案页导航补齐 Featured 入口（与首页/About 一致）。
- 9 语言 × 15 页全量重建；`check_i18n.py` 与 `check_structure.py` 均 0 error。
---

## 15. 品牌切换（v6，2026-11-06）

| 项目 | 内容 |
| --- | --- |
| 品牌字标 | **DAWNSPRING**（旧字标已退役） |
| 英文法定名 | **Hainan Dawnspring International Trade Co., Ltd.** |
| 中文法定名 | 海南晓昱源国际贸易有限公司（保持不变） |
| Logo | 原标（DS 双球）矢量化资产来自 `brand/logo/original/`，站点发布副本在 `web/assets/img/` |
| 页头/页脚 | `logo-horizontal-reverse.svg`（深底横版，高 38px / 页脚 34px，移动 32px） |
| favicon | `assets/img/favicon.svg`（无网格简化版，16/32px）+ `apple-touch-icon` → `logo-mark-512.png` |
| OG 图 | `web/assets/img/og.png`（1200×630，DS 横版 + DAWNSPRING + 品类行），每页输出 `og:image`、`og:image:width/height/alt`、`twitter:image`，`twitter:card=summary_large_image` |
| 域名 | `https://www.dawnspring-intl.com`（canonical / hreflang / OG / sitemap / robots 统一） |
| 邮箱占位 | `info@dawnspring-intl.com`（域名待注册，上线前替换为企业邮箱） |
| 替换范围 | 15 个双语母版（30 处页头/页脚品牌块、15 处 favicon）、9 个 `i18n/*.json`、生成后的 135 页及根页面 |
| 泰文处理 | 泰文音译公司名统一改为英文法定名；地名「ไห่หนาน（海南）」保留泰文 |
| 残留检查 | 旧品牌名与旧占位域名在 `web/**` 残留为 0（`docs/decisions.md` 作为历史决策记录未改写） |

**构建命令不变**：`python _build/build_i18n.py` → `check_i18n.py` / `check_structure.py`。
---

## 16. v6 信息架构（2026-11-06）

| 项目 | 变更 |
| --- | --- |
| 顶级导航 | Home / Solutions / About / Contact（移除 Featured、Quality & Compliance、Markets & Services；不再使用 `index.html#featured` 锚点） |
| 首页顺序 | Hero（双 CTA）→ 业务板块（5 品类 + 2 主推）→ Why us 4 条可验证优势 → 首页内嵌询盘表单 → 信任条 → 精简公司信息 |
| 新增页面 | `solutions.html`（5 品类总览 + 2 主推 + 目标市场/服务） |
| 页面合并 | `quality-compliance.html` → `about.html#quality`；`markets-services.html` → `solutions.html#markets`；每个语言目录生成 noindex + meta refresh 跳转页，旧链接不 404 |
| 品类页 | 左侧 sticky 子模块导航（移动端横向 chips）+ 子模块板块（适用场景/典型方案方向/需提供信息/询盘 CTA）：储能 3、光伏 3、五金 3、电子 3、茶咖 2 |
| Why us | 源头直供、报价透明、文件可追溯、一站式多语（不宣称自有工厂/认证/客户案例/销量） |
| 页面数 | 14 正常页 + 2 跳转页 × 9 语言 = 144 个语言页；sitemap 每语言 13 条（不含 404 与跳转页） |
| i18n | en/zh 全量更新；其余 7 语言用英文占位，增量清单见 `web/_build/delta-report.md` |
| 验收 | `check_i18n.py`（含跳转页）与 `check_structure.py` 0 error；9 语言首页 200；390px 无溢出 |

### v6 追加（2026-11-06）

| 项目 | 内容 |
| --- | --- |
| 顶级导航 | Home / Solutions / About（3 项）；右上角主按钮 Get a quote → `index.html#inquiry`（首页表单锚点） |
| Contact 合并 | 联系方式并入 `about.html#contact`（邮箱/电话/地址/信用代码/响应时效）；`contact.html` 9 语言目录均为 noindex + meta refresh 跳转页 |
| Feedback | 新增 `feedback.html`（仅页脚链接）：反馈类型/留言必填/邮箱选填/隐私同意必填；mailto 兜底 + 「表单待接入」；仅内部处理、不公开、2 个工作日内回复；无公开评分区 |
| 信任替代物 | About 新增：工作日 24 小时内响应、样品政策、文件清单说明；首页信任条保留 |
| 页脚 | 隐私政策 / 意见反馈 / 联系方式（About#contact）/ 9 语言切换 |
| 增量翻译 | `web/_build/delta-report.md`：新增 55 键、变更 11 键（feedback 页、About 新板块、页脚/页头） |
---

## 17. v7 文案通检 + 品类页两级导航（2026-11-06）

| 项目 | 内容 |
| --- | --- |
| 命名 | Solutions → **Products & Solutions / 产品及方案**（文件名不变）；breadcrumb/页脚/首页 CTA 同步 |
| 品类页导航 | 左侧常驻 sticky 两级：L1 五品类（15px、当前高亮、切页面）+ L2 子模块锚点（缩进）；IntersectionObserver scrollspy；删除右侧小列表；移动端顶部横向 chips |
| 文案通检 | 1059 条中文字符串逐句检查，修改 21 条（含老板红框句），清单 `web/_build/copy-review.md` |
| 增量翻译 | `web/_build/delta-report.md`：新增 12 键、变更 370 键（品类/关于页文案、导航命名、About 合并板块） |
| 验收 | 9 语言 153 页重建，`check_i18n.py` / `check_structure.py` 0 error；9 语言首页 200；390px 无溢出 |
| 截图 | `preview/v7-home-1440.png`、`v7-category-1440.png`、`v7-category-mobile.png` |

### v7 修复（task-27）

- 品类页两栏布局提升到页面级：phead 之后全部 section 进入 `catalog-main` 右列，`catalog-nav` 作为页面级 sticky 左栏覆盖整页内容；`top: calc(hdr + 20px)`、`max-height: calc(100vh - hdr - 40px)`、`overflow-y: auto`；宽度 240px、gap 40px。
- L1 当前品类改为 `<span class="is-current" aria-current="page">`（无 href，点击不跳转）；其余 4 个品类保持链接。
- L2 锚点复用平滑滚动与 `scroll-margin-top` 对齐 header。
- 移动端仍为顶部两行横向 chips（≤1024px）。
- 截图：`preview/v7-nav-content-bottom-1440.png`（内容底部导航完整可见）、`v7-sticky-bottom-1440.png`（绝对页底，导航与 footer 同屏可见）。