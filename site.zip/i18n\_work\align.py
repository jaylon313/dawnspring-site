﻿import json, io, re, math

idx = json.load(io.open("_work/en_index.json", encoding="utf-8"))
E = [idx[str(i)]["t"] for i in range(1042)]

STOP = set("the a an of and or to in for on with by as is are be this that it its from at we you your our not no only per into than which who what when where how all any each other more most such can will may".split())

def toks(s):
    s = re.sub(r"<[^>]+>", " ", s)
    s = s.replace("&amp;", " ")
    return [t for t in re.findall(r"[A-Za-z][A-Za-z0-9'\.\-]*", s.lower())]

def numset(s):
    return set(re.findall(r"\d+(?:[.,]\d+)*", s))

def sim(e, t):
    et, tt = toks(e), toks(t)
    if not et: return 0.0
    es = set(et); ts = set(tt)
    econtent = [w for w in es if w not in STOP and len(w) > 2]
    if not econtent: return 0.3
    # exact shared words (technical/brand words survive translation)
    shared = sum(1 for w in econtent if w in ts and len(w) >= 4)
    # numbers
    en_, tn_ = numset(e), numset(t)
    numhit = len(en_ & tn_)
    numpen = len(en_ - tn_)
    base = (shared / max(1, len(econtent)))
    s = 1.6 * base + 0.7 * numhit - 0.7 * numpen
    # length prior
    le, lt = len(e), len(t)
    if le > 0 and lt > 0:
        r = lt / le
        s -= max(0.0, abs(math.log(r / 1.12)) - 0.55) * 1.2
    # tag consistency
    tags_e = re.findall(r"</?[a-zA-Z][^>]*>", e)
    tags_t = re.findall(r"</?[a-zA-Z][^>]*>", t)
    s += 0.8 if tags_e == tags_t else -1.5
    s += 0.4 if (("&amp;" in e) == ("&amp;" in t)) else -0.6
    return s

for lang in ("id", "vi"):
    T = {}
    for n in range(1,5):
        d = json.load(io.open("_work/%s_part%d.json" % (lang,n), encoding="utf-8"))
        T.update(d)
    TV = [T[str(i)] for i in range(1042)]
    N = 1042
    GAP = -1.1
    # DP over (i,j) with band
    BAND = 10
    neg = -1e9
    dp = [[neg]*(N+1) for _ in range(N+1)]
    ptr = [[0]*(N+1) for _ in range(N+1)]
    dp[0][0] = 0.0
    for i in range(N+1):
        lo = max(0, i-BAND); hi = min(N, i+BAND)
        for j in range(lo, hi+1):
            cur = dp[i][j]
            if cur == neg: continue
            if i < N and j < N:
                v = cur + sim(E[i], TV[j])
                if v > dp[i+1][j+1]:
                    dp[i+1][j+1] = v; ptr[i+1][j+1] = 0
            if i < N:
                v = cur + GAP
                if v > dp[i+1][j]:
                    dp[i+1][j] = v; ptr[i+1][j] = 1
            if j < N:
                v = cur + GAP
                if v > dp[i][j+1]:
                    dp[i][j+1] = v; ptr[i][j+1] = 2
    # traceback
    i, j = N, N
    mapping = {}
    missE, missT = [], []
    while i > 0 or j > 0:
        p = ptr[i][j]
        if i > 0 and j > 0 and p == 0:
            mapping[j-1] = i-1; i -= 1; j -= 1
        elif i > 0 and p == 1:
            missE.append(i-1); i -= 1
        elif j > 0 and p == 2:
            missT.append(j-1); j -= 1
        else:
            break
    print("==", lang, "matched:", len(mapping), "unmatched EN:", len(missE), "unused T:", len(missT))
    print("  unmatched EN ids:", sorted(missE)[:40])
    print("  unused T keys:", sorted(missT)[:40])
    # identity rate
    ident = sum(1 for k,v in mapping.items() if k==v)
    print("  identity pairs:", ident)
    # show suspicious
    sus = [(k,v) for k,v in sorted(mapping.items()) if abs(k-v) > 0]
    print("  shifted pairs:", len(sus), sus[:15])
    json.dump({str(k): v for k,v in mapping.items()}, io.open("_work/%s_align.json"%lang,"w",encoding="utf-8"))
