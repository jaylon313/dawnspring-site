import io, json, glob, sys
from collections import defaultdict

raw = io.open('_work/en_source.tsv', encoding='utf-8').read().split('\n')
src = {}
for ln in raw:
    if not ln.strip():
        continue
    i, t = ln.split('\t', 1)
    src[int(i)] = t

lang = sys.argv[1]
tr = {}
for p in sorted(glob.glob('_work/%s_part*.json' % lang)):
    tr.update({int(k): v for k, v in json.load(io.open(p, encoding='utf-8')).items()})

groups = defaultdict(list)
for i, e in src.items():
    groups[e].append(i)

bad = 0
for e, ids in groups.items():
    if len(ids) < 2:
        continue
    vals = {tr[i] for i in ids}
    if len(vals) > 1:
        bad += 1
        print('INCONSISTENT:', repr(e[:60]), '->', len(vals), 'variants')
        for i in ids:
            print('   ', i, tr[i][:80])
print('inconsistent groups:', bad)
