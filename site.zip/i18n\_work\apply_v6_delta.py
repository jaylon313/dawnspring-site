"""Apply v6 delta translations to a language file.

Usage:
    python apply_v6_delta.py <lang> <chunk1.json> [<chunk2.json> ...]

Each chunk is a flat JSON object {"<id>": "<translated text>"} where ids come from
_work/new_en_index.json (id -> {p: [path keys], t: English}).

The target file web/i18n/<lang>.json is updated in place (paths from new_en_index.json).
"""
import io
import json
import os
import sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WORK = os.path.join(BASE, "_work")

if len(sys.argv) < 3:
    raise SystemExit("usage: python apply_v6_delta.py <lang> <chunk.json> [...]")

lang = sys.argv[1]
files = sys.argv[2:]

with io.open(os.path.join(WORK, "new_en_index.json"), encoding="utf-8") as f:
    index = json.load(f)

merged = {}
for path in files:
    with io.open(path, encoding="utf-8") as f:
        data = json.load(f)
    merged.update({str(k): v for k, v in data.items()})

unknown = [k for k in merged if k not in index]
if unknown:
    raise SystemExit("unknown ids: %d e.g. %s" % (len(unknown), unknown[:5]))

target = os.path.join(BASE, lang + ".json")
with io.open(target, encoding="utf-8") as f:
    doc = json.load(f)

applied = 0
for ident, value in merged.items():
    if not isinstance(value, str) or not value.strip():
        continue
    node = doc
    path = index[ident]["p"]
    for part in path[:-1]:
        node = node[part]
    node[path[-1]] = value
    applied += 1

with io.open(target, "w", encoding="utf-8") as f:
    json.dump(doc, f, ensure_ascii=False, indent=1)

still = 0
for ident, info in index.items():
    node = doc
    for part in info["p"]:
        node = node[part]
    if node == info["t"]:
        still += 1
print("wrote:", target, "applied:", applied, "still english:", still, "/", len(index))
