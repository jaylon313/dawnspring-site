# i18n / 翻译文件说明

本目录是 9 语言站点的文案源。页面由 `../_build/build_i18n.py` 生成，**不要直接改 `/en/`、`/zh/` 等目录下的 HTML**（重跑构建会被覆盖）。

## 文件状态

| 文件 | 语言 | 状态 | 说明 |
| --- | --- | --- | --- |
| `en.json` | English | ✅ complete | 键值与英文页面一致 |
| `zh.json` | 中文 | ✅ complete | 键值与 `en.json` 完全一致 |
| `id.json` | Bahasa Indonesia | ✅ complete | 译文已交付 |
| `vi.json` | Tiếng Việt | ✅ complete | 译文已交付 |
| `th.json` | ไทย | ✅ complete | 译文已交付 |
| `ms.json` | Bahasa Melayu | ✅ complete | 译文已交付 |
| `fil.json` | Filipino | ✅ complete | 译文已交付 |
| `es.json` | Español | ✅ complete | 译文已交付 |
| `pt.json` | Português | ✅ complete | 译文已交付 |

## JSON 结构

```jsonc
{
  "language": "id",
  "bcp47": "id",
  "status": "skeleton",          // 翻译完成后改为 "complete"
  "generated": "2026-11-06",
  "note": "...",
  "shared": {                    // 导航 / 页脚（全站共用）
    "shared.span.1": "Home",
    "shared.span.2": "..."
  },
  "pages": {
    "index": {
      "title": "页面 <title>",
      "description": "meta description",
      "strings": {               // 该页正文中所有 EN/ZH 对
        "index.h1.1": "A practical China supply partner for <em>energy storage</em> …",
        "index.p.3": "..."
      }
    },
    "about": { "...": "..." }
  }
}
```

## 翻译规则（重要）

1. **只改字符串值**；`language`、`bcp47`、`status`、`shared` / `pages` / `strings` 的键名与数量**一字不改**。
2. 保留值中的 HTML 片段：`<em>`、`<strong>`、`<a>`、`<span>`、`&amp;` 等必须原样保留，只翻译其中文字（否则页面会破版或链接失效）。
3. 公司法定英文名 `Hainan Dawnspring International Trade Co., Ltd.` 不建议翻译；中文名保持“海南晓昱源国际贸易有限公司”。
4. 术语一致性：TBD / MOQ / Incoterms / FOB / CIF / kWh / kW 等技术缩写保留原文；TBD 也可译为“待确认（TBD）”。
5. 不添加原文没有的承诺（认证、销量、客户案例、工厂规模）。合规底线与英文一致。
6. 不要用机器翻译直接产出最终稿；需母语者校对。
7. 标点：中文用全角标点；其他语言按各自习惯；引号避免破坏 JSON（JSON 内用 `\"` 转义）。

## 更新译文后

1. 校验 JSON 合法：`python -c "import json;json.load(open('id.json',encoding='utf-8'))"`。
2. 把 `status` 改为 `complete`。
3. 运行 `python _build/build_i18n.py` 重新渲染（构建已直接读取本目录 JSON）。
4. 重跑 `python _build/build_i18n.py` 与 `python _build/check_i18n.py`，并在浏览器抽查导航、长段落与表格。

## 自检

```powershell
cd "D:\National Business\web"
python _build/check_i18n.py      # 9 语言 × 15 页链接、hreflang、下拉、JSON 键一致性
```

期望输出 `errors: 0`。
