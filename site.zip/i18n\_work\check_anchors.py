import io, json, glob, sys

raw = io.open('_work/en_source.tsv', encoding='utf-8').read().split('\n')
src = {}
for ln in raw:
    if not ln.strip():
        continue
    i, t = ln.split('\t', 1)
    src[int(i)] = t

lang = sys.argv[1]
tr = {}
for p in sorted(glob.glob('_work/%s_part*.json' % lang)):
    tr.update({int(k): v for k, v in json.load(io.open(p, encoding='utf-8')).items()})

PAIRS = [
    ('Home', 'Início'), ('Products', 'Produtos'), ('All categories', 'Todas as categorias'),
    ('Product category', 'Categoria de produto'), ('Scope', 'Escopo'),
    ('Payment', 'Pagamento'), ('Incoterm', 'Incoterm'), ('Documents', 'Documentos'),
    ('Available', 'Disponível'), ('Status', 'Status'),
]
for token, want in PAIRS:
    sids = [i for i in range(1042) if src[i] == token]
    got = [(i, tr.get(i)) for i in sids]
    wrong = [(i, v) for i, v in got if v != want]
    print('%-18s src=%d wrong=%s' % (token, len(sids), wrong[:6]))
print('keys:', len(tr), 'missing:', [i for i in range(1042) if i not in tr][:10])
