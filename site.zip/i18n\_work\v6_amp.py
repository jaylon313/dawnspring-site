﻿import json, io, re
def flat(o,p=""):
    out={}
    if isinstance(o,dict):
        for k,v in o.items(): out.update(flat(v,p+"."+k))
    elif isinstance(o,str): out[p]=o
    return out
raw = re.compile(r"&(?![a-zA-Z]+;|#\d+;)")
for f in ("en.json","id.json","vi.json"):
    d = flat({k: json.load(io.open(f,encoding="utf-8"))[k] for k in ("shared","pages")})
    ks = [k for k,v in d.items() if raw.search(v)]
    print(f, len(ks), ks[:4])
