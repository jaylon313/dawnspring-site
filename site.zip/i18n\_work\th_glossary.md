# 泰语（th）术语表 — Glossary

| English | Thai | 备注 |
|---|---|---|
| Hainan Dawnspring International Trade Co., Ltd. | Hainan Dawnspring International Trade Co., Ltd. | 法定名首次出现保留英文全称 + 泰语括注 |
| Dawnspring | Dawnspring / เสี่ยวอวี๋ยวียน | 品牌名保留拉丁写法 |
| B2B sourcing | การจัดหาแบบ B2B | |
| inquiry | การสอบถาม / คำขอใบเสนอราคา | 表单/按钮用「สอบถาม」 |
| quotation | ใบเสนอราคา | |
| quote (v.) | เสนอราคา | |
| MOQ | MOQ | 不译，保留缩写；首次可注「ปริมาณสั่งซื้อขั้นต่ำ」 |
| Incoterms / Incoterm | Incoterms / Incoterm | 保留 |
| lead time | ระยะเวลาจัดส่ง | |
| energy storage | การกักเก็บพลังงาน / ระบบกักเก็บพลังงาน | 系统实体用「ระบบกักเก็บพลังงาน」 |
| solar PV | โซลาร์ PV | |
| hybrid inverter | อินเวอร์เตอร์ไฮบริด | |
| battery | แบตเตอรี่ | |
| load profile | โปรไฟล์โหลด | |
| warranty | การรับประกัน | |
| certificate | ใบรับรอง | |
| test report | รายงานผลการทดสอบ | |
| pre-shipment inspection | การตรวจสอบก่อนการจัดส่ง | |
| freight forwarder | ผู้รับจัดการขนส่งสินค้า | |
| consolidation | การรวมสินค้า | |
| private label | ฉลากส่วนตัว | 首次可注 (private label) |
| EPC contractor | ผู้รับเหมา EPC | |
| wholesaler | ผู้ค้าส่ง | |
| distributor | ผู้จัดจำหน่าย | |
| customs declaration | พิธีการศุลกากร | |
| business scope | ขอบเขตธุรกิจ | |
| registered capital | ทุนจดทะเบียน | |
| credit code | รหัสเครดิต | 统一社会信用代码 |
| quality & compliance | คุณภาพและการปฏิบัติตามข้อกำหนด | |
| markets & services | ตลาดและบริการ | |
| privacy policy | นโยบายความเป็นส่วนตัว | |
| feature / featured | แนะนำ | |
| specification | ข้อกำหนด | |
| datasheet | เอกสารข้อมูล | |
| grade (tea/coffee) | ระดับชั้น | |
| lot | ล็อต | |
| sample | ตัวอย่าง | |
| origin | แหล่งกำเนิด | |
