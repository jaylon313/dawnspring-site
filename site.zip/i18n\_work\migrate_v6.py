"""Carry over v5 translations to the v6 string set by matching English source text.

Inputs (all under web/i18n/):
  _work/en_source.tsv        old (v5) id -> English text
  _work/<lang>_part*.json    old (v5) id -> translated text (per translator)
  en.json                    new (v6) English master
  <lang>.json                current (v6) language file (mostly English placeholders)

Outputs:
  <lang>.json                v6 file with carried-over translations (backup in _work/backup-v6/)
  _work/new_en_index.json    new id -> {p: [path keys], t: English}
  _work/v6_todo.tsv          id<TAB>English for strings with no v5 translation match
"""
import io
import json
import os
import shutil

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WORK = os.path.join(BASE, "_work")
BACKUP = os.path.join(WORK, "backup-v6")
LANGS = ["id", "vi", "th", "ms", "fil", "es", "pt"]

os.makedirs(BACKUP, exist_ok=True)


def load(path):
    with io.open(path, encoding="utf-8") as f:
        return json.load(f)


def dump(path, obj):
    with io.open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)


def walk(obj, prefix=()):
    """Yield (path tuple, string value)."""
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield from walk(v, prefix + (k,))
    elif isinstance(obj, str):
        yield prefix, obj


# --- old English text by id -------------------------------------------------
old_text = {}
with io.open(os.path.join(WORK, "en_source.tsv"), encoding="utf-8") as f:
    for line in f:
        line = line.rstrip("\n")
        if not line:
            continue
        ident, text = line.split("\t", 1)
        old_text[ident] = text

# --- old translation maps: english text -> translated text ------------------
old_maps = {}
for lang in LANGS:
    merged = {}
    for name in sorted(os.listdir(WORK)):
        if name.startswith(lang + "_part") and name.endswith(".json"):
            merged.update(load(os.path.join(WORK, name)))
    text_map = {}
    for ident, translated in merged.items():
        src = old_text.get(ident)
        if src is not None and src not in text_map:
            text_map[src] = translated
    old_maps[lang] = text_map

# --- new English master -----------------------------------------------------
en_doc = load(os.path.join(BASE, "en.json"))
new_paths = [(path, text) for path, text in walk({k: en_doc[k] for k in ("shared", "pages")})]

new_index = {}
for i, (path, text) in enumerate(new_paths):
    new_index[str(i)] = {"p": list(path), "t": text}
dump(os.path.join(WORK, "new_en_index.json"), new_index)

# --- migrate each language --------------------------------------------------
stats = {}
touched_any = set()
for lang in LANGS:
    path_file = os.path.join(BASE, lang + ".json")
    shutil.copyfile(path_file, os.path.join(BACKUP, lang + ".json"))

    doc = load(path_file)
    cur = {p: v for p, v in walk({k: doc[k] for k in ("shared", "pages")})}
    carried = kept = todo = 0
    for p, en_text in new_paths:
        existing = cur.get(p)
        if existing is not None and existing != en_text:
            kept += 1
            continue
        tr = old_maps[lang].get(en_text)
        if tr is not None:
            node = doc
            for part in p[:-1]:
                node = node[part]
            node[p[-1]] = tr
            carried += 1
        else:
            todo += 1
            touched_any.add(en_text)
    dump(path_file, doc)
    stats[lang] = (carried, kept, todo)

# --- shared todo list -------------------------------------------------------
todo_rows = [(i, info["t"]) for i, info in new_index.items() if info["t"] in touched_any]
with io.open(os.path.join(WORK, "v6_todo.tsv"), "w", encoding="utf-8", newline="\n") as f:
    for ident, text in todo_rows:
        f.write(ident + "\t" + text + "\n")

for lang, (carried, kept, todo) in stats.items():
    print("%-4s carried=%4d kept=%4d remaining=%4d" % (lang, carried, kept, todo))
print("todo strings (shared):", len(todo_rows))
