/* ==========================================================================
   Hainan Dawnspring International Trade Co., Ltd. — site v1
   Vanilla JS, no dependencies. Works when opened directly via file://.
   Handles: language switch (EN default / ZH), mobile navigation, inquiry form
   placeholder, footer year.
   ========================================================================== */
(function () {
  'use strict';

  var root = document.documentElement;
  var STORAGE_KEY = 'xyy-lang';
  var DEFAULT_LANG = 'en';

  function readStoredLang() {
    try {
      var v = window.localStorage.getItem(STORAGE_KEY);
      return v === 'zh' || v === 'en' ? v : null;
    } catch (err) {
      return null;
    }
  }

  function writeStoredLang(lang) {
    try {
      window.localStorage.setItem(STORAGE_KEY, lang);
    } catch (err) {
      /* file:// or private mode — ignore, the switch still works for the session */
    }
  }

  function langFromQuery() {
    try {
      var p = new URLSearchParams(window.location.search).get('lang');
      return p === 'zh' || p === 'en' ? p : null;
    } catch (err) {
      return null;
    }
  }

  function setMeta(selector, value) {
    var el = document.querySelector(selector);
    if (el && value) el.setAttribute('content', value);
  }

  function applyLang(lang) {
    if (lang !== 'zh' && lang !== 'en') lang = DEFAULT_LANG;

    root.setAttribute('data-lang', lang);
    root.setAttribute('lang', lang === 'zh' ? 'zh-CN' : 'en');

    var title = lang === 'zh' ? root.getAttribute('data-title-zh') : root.getAttribute('data-title-en');
    if (title) document.title = title;

    var desc = lang === 'zh' ? root.getAttribute('data-desc-zh') : root.getAttribute('data-desc-en');
    setMeta('meta[name="description"]', desc);

    var buttons = document.querySelectorAll('[data-set-lang]');
    for (var i = 0; i < buttons.length; i++) {
      var on = buttons[i].getAttribute('data-set-lang') === lang;
      buttons[i].setAttribute('aria-pressed', on ? 'true' : 'false');
      buttons[i].classList.toggle('is-on', on);
    }

    var live = document.getElementById('lang-status');
    if (live) {
      live.textContent = lang === 'zh' ? '语言已切换为中文' : 'Language switched to English';
    }
  }

  /* ---------- language switch ----------
     Only the bilingual master pages (kept in _build/source, not published as
     language pages) use the JS toggle. Generated single-language pages set
     <html lang> statically and switch through the <details> dropdown links. */
  if (root.hasAttribute('data-title-en')) {
    var stored = langFromQuery() || readStoredLang();
    applyLang(stored || root.getAttribute('data-lang') || DEFAULT_LANG);

    document.addEventListener('click', function (e) {
      var btn = e.target.closest ? e.target.closest('[data-set-lang]') : null;
      if (!btn) return;
      var lang = btn.getAttribute('data-set-lang');
      applyLang(lang);
      writeStoredLang(lang);
      btn.focus();
    });
  }

  /* ---------- mobile navigation ---------- */
  var burger = document.querySelector('.burger');
  var nav = document.getElementById('nav');

  function closeNav() {
    if (!nav || !burger) return;
    nav.classList.remove('is-open');
    burger.setAttribute('aria-expanded', 'false');
  }

  if (burger && nav) {
    burger.addEventListener('click', function () {
      var open = nav.classList.toggle('is-open');
      burger.setAttribute('aria-expanded', open ? 'true' : 'false');
      if (open) {
        var first = nav.querySelector('a');
        if (first) first.focus({ preventScroll: true });
      }
    });

    nav.addEventListener('click', function (e) {
      if (e.target.closest && e.target.closest('a')) closeNav();
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') {
        closeNav();
        if (burger.getAttribute('aria-expanded') === 'true') burger.focus();
      }
    });

    document.addEventListener('click', function (e) {
      if (!nav.classList.contains('is-open')) return;
      if (nav.contains(e.target) || burger.contains(e.target)) return;
      closeNav();
    });

    window.addEventListener('resize', function () {
      if (window.innerWidth > 1200) closeNav();
    });
  }

  /* ---------- inquiry form (placeholder — no backend yet) ---------- */
  var form = document.getElementById('inquiry-form') || document.getElementById('feedback-form');
  var isFeedback = form && form.id === 'feedback-form';
  if (form) {
    var status = document.getElementById('form-status') || document.getElementById('feedback-status');

    form.addEventListener('submit', function (e) {
      /* v1 has no backend: never actually post, explain the next step instead. */
      e.preventDefault();

      if (typeof form.checkValidity === 'function' && !form.checkValidity()) {
        var firstInvalid = form.querySelector(':invalid');
        if (firstInvalid) firstInvalid.focus();
        if (status) {
          status.className = 'form__status is-shown';
          status.textContent =
            (document.documentElement.lang === 'zh-CN')
              ? '请完整填写标有 * 的必填项，然后再提交。'
              : 'Please complete all required fields marked with * before submitting.';
        }
        return;
      }

      var lang = document.documentElement.lang === 'zh-CN' ? 'zh' : 'en';
      if (status) {
        status.className = 'form__status is-shown';
        if (lang === 'zh') {
          status.innerHTML =
            '<strong>表单待接入。</strong>本页暂未连接邮件服务，表单内容不会被发送。' +
            '请将上述信息直接发送至 <a href="mailto:info@dawnspring-intl.com">info@dawnspring-intl.com</a>' +
            '（地址待补充）。我们通常会把询盘转给对应品类负责人。';
        } else {
          status.innerHTML =
            '<strong>Form pending integration.</strong> This page is not connected to a mail service yet, ' +
            'so nothing has been sent. Please email the same details to ' +
            '<a href="mailto:info@dawnspring-intl.com">info@dawnspring-intl.com</a> (address TBD). ' +
            'We will route your inquiry to the relevant category owner.';
        }
        status.focus({ preventScroll: true });
      }
    });
  }


  /* ---------- v7: category sub-module scrollspy (sticky two-level nav) ---------- */
  var l2nav = document.querySelector('.catalog-l2');
  if (l2nav && 'IntersectionObserver' in window) {
    var l2links = Array.prototype.slice.call(l2nav.querySelectorAll('a[href^="#"]'));
    var l2map = {};
    l2links.forEach(function (a) {
      var id = a.getAttribute('href').slice(1);
      var sec = document.getElementById(id);
      if (sec) l2map[id] = a;
    });
    var l2sections = Object.keys(l2map).map(function (id) { return document.getElementById(id); });
    var setActive = function (id) {
      l2links.forEach(function (a) { a.classList.remove('is-active'); });
      if (l2map[id]) l2map[id].classList.add('is-active');
    };
    var spy = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) setActive(entry.target.id);
      });
    }, { rootMargin: '-120px 0px -55% 0px', threshold: 0 });
    l2sections.forEach(function (s) { spy.observe(s); });
    if (l2sections.length) setActive(l2sections[0].id);
  }

  /* ---------- footer year ---------- */
  var years = document.querySelectorAll('[data-year]');
  for (var y = 0; y < years.length; y++) {
    years[y].textContent = String(new Date().getFullYear());
  }

  /* ---------- mark that JS is available (progressive enhancement hook) ---------- */
  root.classList.add('has-js');
})();
