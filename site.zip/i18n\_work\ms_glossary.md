# Glosari Terjemahan — Bahasa Melayu (ms)

Dokumen sumber: `_work/en_source.tsv` (1042 rentetan). Gaya: Bahasa Melayu baku, formal, bertulis (B2B).

| English | Bahasa Melayu | Nota |
|---|---|---|
| energy storage | penyimpanan tenaga | |
| solar PV | solar PV / fotovoltaik suria | "solar PV" dikekalkan dalam teks teknikal |
| battery | bateri | |
| hybrid inverter | penyongsang hibrid | |
| quotation | sebutharga | kata nama |
| to quote | memberikan sebutharga | |
| inquiry | pertanyaan | |
| MOQ | MOQ (kuantiti pesanan minimum) | singkatan dikekalkan |
| lead time | masa pendahuluan | |
| Incoterms | Incoterms | dikekalkan (EXW/FOB/CIF) |
| pre-shipment inspection | pemeriksaan sebelum penghantaran | |
| supplier | pembekal | |
| consolidation | penggabungan | |
| private label | label peribadi | |
| wholesaler | pemborong | |
| EPC contractor | kontraktor EPC | EPC dikekalkan |
| certificate | sijil | |
| test report | laporan ujian | |
| warranty | jaminan | bukan "waranti" |
| sample | sampel | |
| packaging | pembungkusan | |
| business scope | skop perniagaan | |
| registered capital | modal berdaftar | |
| Unified Social Credit Code | Kod Kredit Sosial Bersepadu | |
| customs declaration | pengisytiharan kastam | |
| bill of lading / transport documents | dokumen pengangkutan | |
| balance of system | komponen sokongan sistem (BOS) | |
| off-grid | luar grid | |
| load profile | profil beban | |
| private-label / OEM | OEM / ODM | singkatan dikekalkan |

Nama syarikat: **Hainan Dawnspring International Trade Co., Ltd.** dikekalkan dalam bahasa Inggeris penuh; pada kemunculan pertama boleh ditambah kurungan: "Syarikat Perdagangan Antarabangsa Hainan Dawnspring". Jenama **DAWNSPRING** dikekalkan.
