import io, json, glob

lang = 'es'

raw = io.open('_work/en_source.tsv', encoding='utf-8').read().split('\n')
src = {}
for ln in raw:
    if not ln.strip():
        continue
    i, t = ln.split('\t', 1)
    src[int(i)] = t

data = {}
for p in sorted(glob.glob('_work/%s_part*.json' % lang)):
    for k, v in json.load(io.open(p, encoding='utf-8')).items():
        data[int(k)] = v

# Old mapping: keys 220..878 hold translations of src 221..879 (one-off).
# Shift those keys up by one so key == source id, then add src 220.
new = {}
for k, v in data.items():
    if 220 <= k <= 878:
        new[k + 1] = v
    else:
        new[k] = v

# src 220 -> provided translation
new[220] = 'Electrónica de consumo'

# rebuild parts
parts = [
    (0, 219, '_work/es_part1.json'),
    (220, 440, '_work/es_part2.json'),
    (441, 660, '_work/es_part3.json'),
    (661, 879, '_work/es_part4.json'),
    (880, 1041, '_work/es_part5.json'),
]
assert sorted(new) == list(range(1042)), (len(new), [i for i in range(1042) if i not in new][:5])
for lo, hi, path in parts:
    d = {str(i): new[i] for i in range(lo, hi + 1)}
    with io.open(path, 'w', encoding='utf-8') as f:
        json.dump(d, f, ensure_ascii=False, indent=1, sort_keys=False)
    print('wrote', path, len(d))
