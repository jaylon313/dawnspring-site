# Glosariyo ng Salin — Filipino (fil)

Pinagmulan: `_work/en_source.tsv` (1042 string). Estilo: pormal na Filipino/Tagalog, B2B.

| English | Filipino | Tala |
|---|---|---|
| energy storage | imbakan ng enerhiya | |
| solar PV | solar PV / photovoltaic | "solar PV" pinananatili sa teknikal na teksto |
| battery | baterya | |
| hybrid inverter | hybrid inverter | terminong teknikal; pinananatili |
| quotation | quotation / siping | "quotation" ang gamit sa B2B; "siping" sa paliwanag |
| inquiry | pagtatanong / inquiry | |
| MOQ | MOQ (minimum order quantity) | daglat pinananatili |
| lead time | lead time / oras ng paghahatid | |
| Incoterms | Incoterms | pinananatili (EXW/FOB/CIF) |
| pre-shipment inspection | pre-shipment inspection | pinananatili |
| supplier | supplier / tagapagtustos | |
| consolidation | consolidation / pagsasama-sama | |
| private label | private label | pinananatili |
| wholesaler | wholesaler / pakyawan | |
| EPC contractor | EPC contractor | pinananatili |
| certificate | sertipiko | |
| test report | ulat ng pagsusulit | |
| warranty | warranty / garantiya | |
| sample | sample / sampol | |
| packaging | packaging / pagbabalot | |
| business scope | saklaw ng negosyo | |
| registered capital | rehistradong kapital | |
| Unified Social Credit Code | Unified Social Credit Code | opisyal na pangalan, pinananatili |
| customs declaration | deklarasyon sa customs | |
| transport documents | mga dokumento sa transportasyon | |
| balance of system | balance-of-system (BOS) | |
| off-grid | off-grid | |
| load profile | load profile | |
| inquiry form | form ng pagtatanong | |

Pangalan ng kumpanya: **Hainan Dawnspring International Trade Co., Ltd.** pinananatili sa buong Ingles; sa unang paglitaw maaaring dagdagan ng paliwanag sa Filipino. Brand na **DAWNSPRING** pinananatili.
