# Glossário PT-BR — Hainan Dawnspring International Trade Co., Ltd.

Registro: português do Brasil, B2B formal (tratamento "você" institucional / impessoal).
Entidades HTML e tags (`&amp;`, `<em>`, `<a href="…">`, `<span data-year>`) são preservadas.

| EN | PT-BR | Nota |
|---|---|---|
| B2B | B2B | sigla mantida |
| inquiry | consulta | |
| quotation / quote | cotação | por escrito, com premissas e validade |
| MOQ | MOQ (quantidade mínima de pedido) | sigla + explicação na 1ª ocorrência |
| lead time | prazo de entrega | |
| Incoterm | Incoterm | não traduzir |
| EXW / FOB / CIF | EXW / FOB / CIF | intactos |
| pre-shipment inspection | inspeção pré-embarque | |
| certificate of origin | certificado de origem | |
| packing list | packing list | termo consagrado no comércio exterior BR |
| commercial invoice | commercial invoice / fatura comercial | usar "fatura comercial" em texto corrido |
| freight forwarder | agente de carga | |
| consolidation | consolidação | de cargas/pedidos |
| supplier | fornecedor | |
| specification / datasheet | especificação / ficha técnica | |
| test report | laudo de ensaio | |
| compliance | conformidade | "Quality &amp; Compliance" → "Qualidade e conformidade" |
| warranty | garantia | |
| energy storage (ESS) | armazenamento de energia (ESS) | |
| C&amp;I | C&amp;I (comercial e industrial) | |
| hybrid inverter | inversor híbrido | |
| portable power station | estação de energia portátil | |
| BMS / EMS / PCS | BMS / EMS / PCS | siglas intactas |
| PV module | módulo fotovoltaico | |
| mounting structure | estrutura de fixação | |
| grid code | código de rede | |
| private label | marca própria | |
| OEM / ODM | OEM / ODM | intactas |
| lot | lote | chá/café |
| raw Pu'er (sheng) / ripe (shou) | Pu'er cru (sheng) / maduro (shou) | |
| arabica green beans | grãos verdes de arábica | |
| cupping | prova de xícara (cupping) | |
| traceability | rastreabilidade | |
| customs declaration | declaração aduaneira | |
| business scope | objeto social | |
| credit code | código de crédito social unificado | |
| registered capital | capital registrado | |
| limited liability company | sociedade limitada | |
| wholesaler | atacadista | |
| EPC contractor | contratante EPC | |
| end user | usuário final | |
| mini-grid developer | desenvolvedor de minirredes | |
| WeChat | WeChat | |
| DAWNSPRING / Dawnspring | DAWNSPRING / Dawnspring | marca intacta |
| Hainan Dawnspring International Trade Co., Ltd. | Hainan Dawnspring International Trade Co., Ltd. | razão social em inglês; parêntese local na 1ª ocorrência se útil |
