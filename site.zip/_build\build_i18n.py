#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Build the multilingual static site from bilingual master pages.

Architecture
------------
* `web/_build/source/*.html` are the bilingual masters (EN + ZH spans, the
  markup that v1/v2 used). They are the single editable source.
* This script extracts every EN/ZH pair, writes `web/i18n/<lang>.json`
  (en/zh complete, the remaining 7 are EN-placeholder skeletons), and renders
  one fully static single-language page tree per language under
  `web/<lang>/<page>.html` with:
    - <html lang> + <title>/<meta>/OG per language
    - nine <link rel="alternate" hreflang> entries + x-default
    - a native <details> language dropdown of plain links (no JS, no fetch)
    - all internal links kept inside the same language directory
* Root pages become tiny redirect stubs to /en/ (hosting + file:// friendly);
  root 404.html stays a real 404 page in English.

Run:  python _build/build_i18n.py
"""
from __future__ import annotations

import html as html_lib
import json
import shutil
import sys
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent          # web/
SOURCE = Path(__file__).resolve().parent / "source"    # web/_build/source
I18N = ROOT / "i18n"
DOMAIN = "https://www.dawnspring-intl.com"                     # TODO replace before launch
PAGES = [
    "index", "about", "solutions", "products", "energy-storage", "solar-pv",
    "hardware-tools", "consumer-electronics", "tea-coffee",
    "feedback", "privacy", "solution-solar-storage-ev", "solution-yunnan-tea-coffee",
    "404",
]
# legacy URLs kept alive as noindex redirect pages (v6 merge)
REDIRECTS = {
    "quality-compliance": ("about.html", "#quality"),
    "markets-services": ("solutions.html", "#markets"),
    "contact": ("about.html", "#contact"),
}
VOID = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link",
        "meta", "param", "source", "track", "wbr"}

LANGS = [
    # code, native label, BCP47 html lang, status
    ("en", "English", "en", "complete"),
    ("zh", "中文", "zh-CN", "complete"),
    ("id", "Bahasa Indonesia", "id", "skeleton"),
    ("vi", "Tiếng Việt", "vi", "skeleton"),
    ("th", "ไทย", "th", "skeleton"),
    ("ms", "Bahasa Melayu", "ms", "skeleton"),
    ("fil", "Filipino", "fil", "skeleton"),
    ("es", "Español", "es", "skeleton"),
    ("pt", "Português", "pt", "skeleton"),
]
LANG_META = {c: (label, bcp, status) for c, label, bcp, status in LANGS}


# ---------------------------------------------------------------- tiny DOM
class Raw(str):
    """Pre-escaped markup (entity/char refs, comments, doctype): never re-escaped."""


class Node:
    __slots__ = ("tag", "attrs", "children")

    def __init__(self, tag, attrs=None, children=None):
        self.tag = tag
        self.attrs = list(attrs or [])
        self.children = list(children or [])

    def get(self, name, default=None):
        for k, v in self.attrs:
            if k == name:
                return v if v is not None else ""
        return default

    def set(self, name, value):
        for i, (k, _) in enumerate(self.attrs):
            if k == name:
                self.attrs[i] = (k, value)
                return
        self.attrs.append((name, value))

    def classes(self):
        return (self.get("class") or "").split()


class Parser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.root = Node("#document")
        self.stack = [self.root]

    def handle_starttag(self, tag, attrs):
        node = Node(tag, attrs)
        self.stack[-1].children.append(node)
        if tag not in VOID:
            self.stack.append(node)

    def handle_startendtag(self, tag, attrs):
        self.stack[-1].children.append(Node(tag, attrs))

    def handle_endtag(self, tag):
        for i in range(len(self.stack) - 1, 0, -1):
            if self.stack[i].tag == tag:
                del self.stack[i:]
                return

    def handle_data(self, data):
        self.stack[-1].children.append(data)

    def handle_entityref(self, name):
        self.stack[-1].children.append(Raw("&%s;" % name))

    def handle_charref(self, name):
        self.stack[-1].children.append(Raw("&#%s;" % name))

    def handle_comment(self, data):
        self.stack[-1].children.append(Raw("<!--%s-->" % data))

    def handle_decl(self, decl):
        self.stack[-1].children.append(Raw("<!%s>" % decl))


def esc_attr(value):
    return (value or "").replace("&", "&amp;").replace('"', "&quot;").replace("<", "&lt;")


def escape_text(s):
    """Escape bare ampersands. Entity references are separate nodes
    (HTMLParser convert_charrefs=False), so no double escaping occurs."""
    return s.replace("&", "&amp;")


def serialize(node):
    if isinstance(node, Raw):
        return str(node)
    if isinstance(node, str):
        return escape_text(node)
    if node.tag == "#document":
        return "".join(serialize(c) for c in node.children)
    if node.tag in VOID:
        attrs = "".join(' %s="%s"' % (k, esc_attr(v)) if v is not None else " " + k for k, v in node.attrs)
        return "<%s%s>" % (node.tag, attrs)
    attrs = "".join(' %s="%s"' % (k, esc_attr(v)) if v is not None else " " + k for k, v in node.attrs)
    return "<%s%s>%s</%s>" % (node.tag, attrs, "".join(serialize(c) for c in node.children), node.tag)


def parse(text):
    p = Parser()
    p.feed(text)
    p.close()
    return p.root


def inner_html(node):
    return "".join(serialize(c) for c in node.children)


def fragment(markup):
    root = parse(markup)
    frag = Node("#fragment")
    frag.children = [c for c in root.children if isinstance(c, str) or c.tag not in ("html",)]
    return frag.children


def walk(node):
    yield node
    for c in node.children:
        if isinstance(c, Node):
            yield from walk(c)


def find(node, pred):
    for n in walk(node):
        if n is not node and pred(n):
            return n
    return None


def children_pairing(parent, lang):
    """Replace i18n-en/i18n-zh sibling pairs inside one parent with the chosen language."""
    kids = parent.children
    out = []
    i = 0
    while i < len(kids):
        child = kids[i]
        if isinstance(child, Node) and "i18n-en" in child.classes():
            zh = None
            j = i + 1
            while j < len(kids):
                c2 = kids[j]
                if isinstance(c2, str):
                    j += 1
                    continue
                if "i18n-zh" in c2.classes():
                    zh = c2
                break
            chosen = zh if (lang == "zh" and zh is not None) else child
            clone = Node(chosen.tag, [a for a in chosen.attrs], list(chosen.children))
            clone.attrs = [(k, v) for k, v in clone.attrs if k != "class" or True]
            cls = [c for c in clone.classes() if c not in ("i18n-en", "i18n-zh")]
            if cls:
                clone.set("class", " ".join(cls))
            else:
                clone.attrs = [(k, v) for k, v in clone.attrs if k != "class"]
            children_pairing(clone, lang)
            out.append(clone)
            i = (j + 1) if zh is not None else (i + 1)
            continue
        if isinstance(child, Node):
            children_pairing(child, lang)
        out.append(child)
        i += 1
    parent.children = out


def collect_pairs(node, prefix, counters, en_map, zh_map):
    """Record every EN/ZH pair with a stable key (document order within context)."""
    kids = node.children
    for i, child in enumerate(kids):
        if isinstance(child, Node) and "i18n-en" in child.classes():
            zh = None
            j = i + 1
            while j < len(kids):
                c2 = kids[j]
                if isinstance(c2, str):
                    j += 1
                    continue
                if "i18n-zh" in c2.classes():
                    zh = c2
                break
            tag = child.tag
            counters[(prefix, tag)] = counters.get((prefix, tag), 0) + 1
            key = "%s.%s.%d" % (prefix, tag, counters[(prefix, tag)])
            en_map[key] = inner_html(child)
            zh_map[key] = inner_html(zh) if zh is not None else inner_html(child)
            if zh is not None:
                collect_pairs(zh, prefix, counters, en_map, zh_map)
        elif isinstance(child, Node):
            collect_pairs(child, prefix, counters, en_map, zh_map)


def apply_pairs(node, prefix, counters, values, fallback):
    """Replace i18n-en/i18n-zh sibling pairs with the translated string for this page."""
    kids = node.children
    out = []
    i = 0
    while i < len(kids):
        child = kids[i]
        if isinstance(child, Node) and "i18n-en" in child.classes():
            zh = None
            j = i + 1
            while j < len(kids):
                c2 = kids[j]
                if isinstance(c2, str):
                    j += 1
                    continue
                if "i18n-zh" in c2.classes():
                    zh = c2
                break
            tag = child.tag
            counters[(prefix, tag)] = counters.get((prefix, tag), 0) + 1
            key = "%s.%s.%d" % (prefix, tag, counters[(prefix, tag)])
            value = values.get(key)
            if value is None:
                value = fallback.get(key, "")
            clone = Node(child.tag, list(child.attrs), fragment(value))
            cls = [c for c in clone.classes() if c not in ("i18n-en", "i18n-zh")]
            if cls:
                clone.set("class", " ".join(cls))
            else:
                clone.attrs = [(k, v) for k, v in clone.attrs if k != "class"]
            out.append(clone)
            i = (j + 1) if zh is not None else (i + 1)
            continue
        if isinstance(child, Node):
            apply_pairs(child, prefix, counters, values, fallback)
        out.append(child)
        i += 1
    node.children = out


def strip_leftover_pairs(node):
    """Keep the English side of any remaining i18n pair (e.g. the skip link,
    which sits outside header/main/footer and is not part of the translated JSON)."""
    kids = node.children
    out = []
    i = 0
    while i < len(kids):
        child = kids[i]
        if isinstance(child, Node) and "i18n-en" in child.classes():
            zh = None
            j = i + 1
            while j < len(kids):
                c2 = kids[j]
                if isinstance(c2, str):
                    j += 1
                    continue
                if "i18n-zh" in c2.classes():
                    zh = c2
                break
            clone = Node(child.tag, list(child.attrs), list(child.children))
            cls = [c for c in clone.classes() if c not in ("i18n-en", "i18n-zh")]
            if cls:
                clone.set("class", " ".join(cls))
            else:
                clone.attrs = [(k, v) for k, v in clone.attrs if k != "class"]
            strip_leftover_pairs(clone)
            out.append(clone)
            i = (j + 1) if zh is not None else (i + 1)
            continue
        if isinstance(child, Node):
            strip_leftover_pairs(child)
        out.append(child)
        i += 1
    node.children = out


def build_value_map(en_payload, lang_payload):
    """Map English source HTML -> delivered translation HTML."""
    vm = {}
    for k, v in en_payload.get("shared", {}).items():
        tv = lang_payload.get("shared", {}).get(k)
        if tv:
            vm.setdefault(v, tv)
    for slug, page in en_payload.get("pages", {}).items():
        lp = lang_payload.get("pages", {}).get(slug, {})
        for k, v in page.get("strings", {}).items():
            tv = lp.get("strings", {}).get(k)
            if tv:
                vm.setdefault(v, tv)
    return vm


def loookup_header_value(en_html, vm):
    """Translation for a header string; a few header-only strings never made it
    into the delivered JSON, so use a close existing string or keep English."""
    if en_html in vm:
        return vm[en_html]
    if en_html == "Featured":
        for k, v in vm.items():
            if k.startswith("Featured: ") and v and ":" in v:
                return v.split(":")[0].strip()
        return en_html
    if en_html == "Get a quote":
        return vm.get("Request a quotation", en_html)
    return en_html


def apply_value_pairs(node, vm, fallback_vm):
    kids = node.children
    out = []
    i = 0
    while i < len(kids):
        child = kids[i]
        if isinstance(child, Node) and "i18n-en" in child.classes():
            zh = None
            j = i + 1
            while j < len(kids):
                c2 = kids[j]
                if isinstance(c2, str):
                    j += 1
                    continue
                if "i18n-zh" in c2.classes():
                    zh = c2
                break
            en_html = inner_html(child)
            value = vm.get(en_html)
            if value is None:
                value = loookup_header_value(en_html, vm)
            if value is None:
                value = en_html
            clone = Node(child.tag, list(child.attrs), fragment(value))
            cls = [c for c in clone.classes() if c not in ("i18n-en", "i18n-zh")]
            if cls:
                clone.set("class", " ".join(cls))
            else:
                clone.attrs = [(k, v) for k, v in clone.attrs if k != "class"]
            out.append(clone)
            i = (j + 1) if zh is not None else (i + 1)
            continue
        if isinstance(child, Node):
            apply_value_pairs(child, vm, fallback_vm)
        out.append(child)
        i += 1
    node.children = out


# ---------------------------------------------------------------- page build
def build_page(slug, lang, source_html, payload, en_payload):
    """Render one single-language page from a bilingual master + i18n JSON."""
    doc = parse(source_html)
    # drop the source doctype; a single one is prepended by the caller
    doc.children = [c for c in doc.children
                    if not (isinstance(c, str) and c.lstrip().lower().startswith("<!doctype"))]
    label, bcp, _default_status = LANG_META[lang]
    status = payload.get("status", _default_status)

    # replace language pairs using the delivered translations (falls back to EN)
    header = find(doc, lambda n: n.tag == "header")
    footer = find(doc, lambda n: n.tag == "footer")
    main = find(doc, lambda n: n.tag == "main")
    lang_code = payload.get("language")
    if lang_code in ("en", "zh"):
        vm = build_value_map(en_payload, payload)
    else:
        # v6: changed header/footer copy is English placeholder until translated
        vm = build_value_map(en_payload, en_payload)
    if lang_code == "en":
        vm["Get a quote"] = "Get a quote"
    if lang_code == "zh":
        vm["Products & Solutions"] = "产品及方案"
    if header is not None:
        apply_value_pairs(header, vm, {})
        nav = find(header, lambda n: n.tag == "nav" and "nav" in n.classes())
        if nav is not None:
            active_map = {"index": "index.html", "about": "about.html",
                          "feedback": "about.html", "privacy": "about.html"}
            if slug in active_map:
                active_href = active_map[slug]
            elif slug == "solutions" or slug.startswith("solution-") or slug in (
                    "energy-storage", "solar-pv", "hardware-tools",
                    "consumer-electronics", "tea-coffee", "products"):
                active_href = "solutions.html"
            else:
                active_href = None
            for n in walk(nav):
                if n.tag == "a" and active_href and n.get("href") == active_href:
                    n.set("aria-current", "page")
    if footer is not None:
        apply_value_pairs(footer, vm, {})
        legal = find(footer, lambda n: n.tag == "div" and "ftr__legal" in n.classes())
        if legal is not None:
            links = "".join(
                '<a href="../%s/%s.html" hreflang="%s" lang="%s"%s>%s</a>'
                % (code, slug, "zh-Hans" if code == "zh" else code, LANG_META[code][1],
                   ' aria-current="page"' if code == lang else "", LANG_META[code][0])
                for code, _, _, _ in LANGS)
            block = ('<p class="ftr__lang"><span class="ftr__lang-k">Language / 语言</span> %s</p>'
                     % links)
            parent = find_parent(footer, legal)
            idx = parent.children.index(legal)
            parent.children[idx:idx] = fragment(block)
    page_values = payload.get("pages", {}).get(slug, {}).get("strings", {})
    page_fallback = en_payload.get("pages", {}).get(slug, {}).get("strings", {})
    if main is not None:
        apply_pairs(main, slug, {}, page_values, page_fallback)
    strip_leftover_pairs(doc)

    title = html_lib.unescape(payload.get("pages", {}).get(slug, {}).get("title") or en_payload["pages"][slug]["title"])
    desc = html_lib.unescape(payload.get("pages", {}).get(slug, {}).get("description") or en_payload["pages"][slug]["description"])

    # <html> attributes
    html_node = find(doc, lambda n: n.tag == "html")
    html_node.set("lang", bcp)
    for attr in ("data-lang", "data-title-en", "data-title-zh", "data-desc-en", "data-desc-zh"):
        html_node.attrs = [(k, v) for k, v in html_node.attrs if k != attr]

    # head: title / description / og / canonical / hreflang
    title_node = find(doc, lambda n: n.tag == "title")
    title_node.children = [title]

    for n in walk(doc):
        if n.tag != "meta":
            continue
        name = (n.get("name") or "").lower()
        prop = (n.get("property") or "").lower()
        if name == "description":
            n.set("content", desc)
        elif prop == "og:title":
            n.set("content", title)
        elif prop == "og:description":
            n.set("content", desc)
        elif prop == "og:url":
            n.set("content", "%s/%s/%s.html" % (DOMAIN, lang, slug))
        elif prop == "og:locale":
            n.set("content", bcp.replace("-", "_"))
        elif name == "twitter:card":
            n.set("content", "summary_large_image")

    head = find(doc, lambda n: n.tag == "head")
    head.children.append("\n  ")
    head.children.append(Node("link", [("rel", "canonical"), ("href", "%s/%s/%s.html" % (DOMAIN, lang, slug))]))
    for code, _, _, _ in LANGS:
        hreflang = "zh-Hans" if code == "zh" else code
        head.children.append("\n  ")
        head.children.append(Node("link", [("rel", "alternate"), ("hreflang", hreflang),
                                           ("href", "%s/%s/%s.html" % (DOMAIN, code, slug))]))
    head.children.append("\n  ")
    head.children.append(Node("link", [("rel", "alternate"), ("hreflang", "x-default"),
                                       ("href", "%s/en/%s.html" % (DOMAIN, slug))]))
    head.children.append("\n  ")
    head.children.append(Node("meta", [("property", "og:image"), ("content", "%s/assets/img/og.png" % DOMAIN)]))
    head.children.append("\n  ")
    head.children.append(Node("meta", [("property", "og:image:width"), ("content", "1200")]))
    head.children.append("\n  ")
    head.children.append(Node("meta", [("property", "og:image:height"), ("content", "630")]))
    head.children.append("\n  ")
    head.children.append(Node("meta", [("property", "og:image:alt"),
                                       ("content", "DAWNSPRING — Hainan Dawnspring International Trade Co., Ltd.")]))
    head.children.append("\n  ")
    head.children.append(Node("meta", [("name", "twitter:image"), ("content", "%s/assets/img/og.png" % DOMAIN)]))
    head.children.append("\n  ")
    head.children.append("\n  ")

    # replace the old EN/ZH toggle with the 9-language dropdown
    old = find(doc, lambda n: n.tag == "div" and "langsw" in n.classes())
    if old is not None and old in walk(doc):
        parent = find_parent(doc, old)
        items = "".join(
            '<li><a href="../%s/%s.html" hreflang="%s" lang="%s"%s>%s</a></li>'
            % (code, slug, "zh-Hans" if code == "zh" else code,
               LANG_META[code][1],
               ' aria-current="page"' if code == lang else "",
               LANG_META[code][0])
            for code, _, _, _ in LANGS
        )
        dropdown = (
            '<details class="langselect" data-lang="%s">'
            '<summary aria-label="Language / 语言">%s</summary>'
            '<ul class="langselect__menu">%s</ul></details>'
        ) % (lang, label, items)
        idx = parent.children.index(old)
        parent.children[idx:idx + 1] = fragment(dropdown)

    # relative asset paths (pages live one directory deeper)
    for n in walk(doc):
        for key in ("href", "src"):
            v = n.get(key)
            if v and v.startswith("assets/"):
                n.set(key, "../" + v)

    # notice for skeleton languages
    if status == "skeleton":
        main = find(doc, lambda n: n.tag == "main")
        notice = (
            '<p class="pending-notice" lang="en"><strong>%s version — content pending.</strong> '
            'This language is being prepared. The page below is shown in English for now. '
            'Translations are loaded from <code>i18n/%s.json</code> once provided.</p>'
        ) % (label, lang)
        main.children.insert(0, "\n    ")
        main.children.insert(1, Node("div", [("class", "wrap")], fragment(notice)))
        main.children.insert(2, "\n    ")

    return "<!DOCTYPE html>\n" + serialize(doc)


def find_parent(root, target):
    for n in walk(root):
        for c in n.children:
            if c is target:
                return n
    return None


# ---------------------------------------------------------------- JSON export
def build_json(slug, source_html, en_obj, zh_obj):
    return {
        "title": en_obj["title"],
        "description": en_obj["description"],
        "strings": en_obj["strings"],
    }


def main():
    if not SOURCE.exists():
        SOURCE.mkdir(parents=True)
        for slug in PAGES:
            src = ROOT / (slug + ".html")
            if src.exists():
                shutil.copy2(src, SOURCE / (slug + ".html"))
            else:
                print("WARNING: source master missing for", slug)
    missing = [s for s in PAGES if not (SOURCE / (s + ".html")).exists()]
    if missing:
        raise SystemExit("source masters missing: %s" % missing)

    sources = {s: (SOURCE / (s + ".html")).read_text(encoding="utf-8") for s in PAGES}

    # shared strings (nav/footer) are taken from the index master only
    en_shared, zh_shared = {}, {}
    idx = parse(sources["index"])
    header = find(idx, lambda n: n.tag == "header")
    footer = find(idx, lambda n: n.tag == "footer")
    collect_pairs(header, "shared", {}, en_shared, zh_shared)
    collect_pairs(footer, "shared", {}, en_shared, zh_shared)

    # per-page strings + titles
    page_meta = {}
    for slug in PAGES:
        src = parse(sources[slug])
        html_node = find(src, lambda n: n.tag == "html")
        en_title = html_node.get("data-title-en") or ""
        zh_title = html_node.get("data-title-zh") or en_title
        en_desc = html_node.get("data-desc-en") or ""
        zh_desc = html_node.get("data-desc-zh") or en_desc
        main = find(src, lambda n: n.tag == "main")
        en_map, zh_map = {}, {}
        collect_pairs(main, slug, {}, en_map, zh_map)
        page_meta[slug] = {
            "en": {"title": en_title, "description": en_desc, "strings": en_map},
            "zh": {"title": zh_title, "description": zh_desc, "strings": zh_map},
            "shared_en": dict(en_shared),
            "shared_zh": dict(zh_shared),
        }

    # JSON files: keep delivered translations; only en.json can be refreshed
    I18N.mkdir(exist_ok=True)
    refresh_en = "--refresh-en" in sys.argv
    for code, label, bcp, status in LANGS:
        target = I18N / (code + ".json")
        if target.exists() and not (refresh_en and code == "en"):
            print("kept translation json:", target.name)
            continue
        payload = {
            "language": code,
            "bcp47": bcp,
            "status": status,
            "generated": "2026-11-06",
            "note": "Translate only the string values. Keep the key paths and the number of keys "
                    "exactly as in en.json. HTML fragments such as <em>, <strong>, <a> and <span> "
                    "must be preserved where present. Do not machine-translate the company name.",
            "shared": dict(en_shared if code != "zh" else zh_shared),
            "pages": {},
        }
        for slug in PAGES:
            if code == "zh":
                payload["pages"][slug] = build_json(slug, sources[slug], page_meta[slug]["zh"], page_meta[slug]["zh"])
            else:
                payload["pages"][slug] = build_json(slug, sources[slug], page_meta[slug]["en"], page_meta[slug]["en"])
        target.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    # render all language directories from the delivered JSON
    payloads = {}
    for code, _, _, _ in LANGS:
        payloads[code] = json.loads((I18N / (code + ".json")).read_text(encoding="utf-8"))
    en_payload = payloads["en"]
    for code, label, bcp, status in LANGS:
        out_dir = ROOT / code
        out_dir.mkdir(exist_ok=True)
        for slug in PAGES:
            page = build_page(slug, code, sources[slug], payloads[code], en_payload)
            (out_dir / (slug + ".html")).write_text(page, encoding="utf-8")
        print("rendered", code, len(PAGES), "pages")

    # legacy URLs -> noindex redirect pages in every language directory
    for code, label, bcp, status in LANGS:
        for old_slug, (target, anchor) in REDIRECTS.items():
            page = """<!DOCTYPE html>
<html lang="%s">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Redirecting</title>
  <meta name="robots" content="noindex">
  <meta http-equiv="refresh" content="0; url=%s%s">
  <link rel="canonical" href="%s/%s/%s%s">
</head>
<body>
  <p><a href="%s%s">Continue</a></p>
</body>
</html>
""" % (bcp, target, anchor, DOMAIN, code, target, anchor, target, anchor)
            (ROOT / code / (old_slug + ".html")).write_text(page, encoding="utf-8")

    # sitemap: index + one sitemap per language
    lines = ['<?xml version="1.0" encoding="UTF-8"?>',
             '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">']
    for code, _, _, _ in LANGS:
        lines.append("  <sitemap><loc>%s/sitemap-%s.xml</loc></sitemap>" % (DOMAIN, code))
    lines.append("</sitemapindex>")
    (ROOT / "sitemap.xml").write_text("\n".join(lines) + "\n", encoding="utf-8")

    for code, _, _, _ in LANGS:
        sm = ['<?xml version="1.0" encoding="UTF-8"?>',
              '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">']
        for slug in PAGES:
            if slug == "404":
                continue
            prio = "1.0" if slug == "index" else "0.7"
            sm.append("  <url><loc>%s/%s/%s.html</loc><changefreq>monthly</changefreq>"
                      "<priority>%s</priority></url>" % (DOMAIN, code, slug, prio))
        sm.append("</urlset>")
        (ROOT / ("sitemap-%s.xml" % code)).write_text("\n".join(sm) + "\n", encoding="utf-8")

    # root stubs + 404 + language chooser
    chooser = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Hainan Dawnspring International Trade Co., Ltd. — choose language</title>
  <meta name="description" content="Language selection for the Hainan Dawnspring International Trade website.">
  <meta http-equiv="refresh" content="0; url=en/index.html">
  <link rel="canonical" href="%s/en/index.html">
  <link rel="stylesheet" href="assets/css/chooser.css">
</head>
<body>
  <main>
    <h1>Choose a language / 选择语言</h1>
    <p>Redirecting to the English site. If your browser does not redirect, use a link below.</p>
    <ul>
""" % DOMAIN
    for code, label, _, _ in LANGS:
        chooser += '      <li><a href="%s/index.html" hreflang="%s">%s</a></li>\n' % (code, code, label)
    chooser += "    </ul>\n  </main>\n</body>\n</html>\n"
    (ROOT / "index.html").write_text(chooser, encoding="utf-8")

    for slug in list(PAGES) + list(REDIRECTS.keys()):
        if slug in ("index", "404"):
            continue
        if slug in REDIRECTS:
            tgt, anch = REDIRECTS[slug]
            stub = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Redirecting… / 页面跳转</title>
  <meta name="robots" content="noindex">
  <meta http-equiv="refresh" content="0; url=en/%s%s">
  <link rel="canonical" href="%s/en/%s%s">
</head>
<body>
  <p><a href="en/%s%s">Continue to the English page</a></p>
</body>
</html>
""" % (tgt, anch, DOMAIN, tgt, anch, tgt, anch)
            (ROOT / (slug + ".html")).write_text(stub, encoding="utf-8")
            continue
        stub = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Redirecting… / 页面跳转</title>
  <meta name="robots" content="noindex">
  <meta http-equiv="refresh" content="0; url=en/%s.html">
  <link rel="canonical" href="%s/en/%s.html">
</head>
<body>
  <p><a href="en/%s.html">Continue to the English page</a> · <a href="zh/%s.html">前往中文页面</a></p>
</body>
</html>
""" % (slug, DOMAIN, slug, slug, slug)
        (ROOT / (slug + ".html")).write_text(stub, encoding="utf-8")

    # root 404: real English 404 page with root-relative asset paths
    en404 = (ROOT / "en" / "404.html").read_text(encoding="utf-8")
    en404 = en404.replace('href="../assets/', 'href="assets/').replace('src="../assets/', 'src="assets/')
    for code, _, _, _ in LANGS:
        en404 = en404.replace('href="../%s/404.html"' % code, 'href="%s/404.html"' % code)
    (ROOT / "404.html").write_text(en404, encoding="utf-8")

    print("root stubs + 404 + sitemaps written")


if __name__ == "__main__":
    main()
