import io, json, glob, re, sys

raw = io.open('_work/en_source.tsv', encoding='utf-8').read().split('\n')
src = {}
for ln in raw:
    if not ln.strip():
        continue
    i, t = ln.split('\t', 1)
    src[int(i)] = t

lang = sys.argv[1] if len(sys.argv) > 1 else 'pt'
tr = {}
for p in sorted(glob.glob('_work/%s_part*.json' % lang)):
    tr.update({int(k): v for k, v in json.load(io.open(p, encoding='utf-8')).items()})

CONCEPTS = {
    'pt': {
        'certificat': 'certificad', 'document': 'document', 'quotation': 'cotaç',
        'quote': 'cotaç', 'sample': 'amostra', 'warranty': 'garantia', 'battery': 'bateria',
        'supplier': 'fornecedor', 'payment': 'pagamento', 'inspection': 'inspeç',
        'delivery': 'entrega', 'price': ('preç', 'preço'), 'quality': 'qualidade',
        'module': 'módulo', 'inverter': 'inversor', 'tool': 'ferramenta',
        'storage': 'armazenamento', 'company': 'empresa', 'language': 'idioma',
        'privacy': 'privacidade', 'compliance': 'conformidade', 'market': 'mercado',
        'origin': 'origem', 'packaging': 'embalagem', 'grade': 'grau', 'harvest': 'colheita',
        'buyer': 'comprador', 'freight': 'frete', 'food': 'aliment', 'safety': 'segurança',
        'capacity': 'capacidade', 'installation': 'instala', 'carrier': 'transportadora',
        'insurance': 'seguro', 'inquiry': 'consulta', 'port': 'porto', 'volume': 'volume',
    },
    'es': {
        'certificat': 'certificad', 'document': 'document', 'quotation': 'cotizaci',
        'sample': 'muestra', 'warranty': 'garant', 'battery': 'bater', 'supplier': 'proveedor',
        'payment': 'pago', 'inspection': 'inspe', 'delivery': 'entrega', 'price': 'precio',
        'quality': 'calidad', 'module': 'módul', 'inverter': 'inversor', 'tool': 'herramient',
        'storage': 'almacenamiento', 'company': 'empresa', 'language': 'idioma',
        'privacy': 'privacidad', 'compliance': 'cumplimiento', 'market': 'mercado',
        'origin': 'origen', 'packaging': 'embalaje', 'grade': 'grado', 'harvest': 'cosecha',
        'buyer': 'comprador', 'freight': 'flete', 'food': 'aliment', 'safety': 'seguridad',
        'capacity': 'capacidad', 'installation': 'instala', 'port': 'puerto',
        'inquiry': 'consulta', 'volume': 'volumen',
    },
}[lang]


def score(en, tx):
    e = en.lower()
    t = tx.lower()
    checks = 0
    ok = 0
    for k, stem in CONCEPTS.items():
        if k in e:
            checks += 1
            stems = stem if isinstance(stem, tuple) else (stem,)
            if any(s in t for s in stems):
                ok += 1
    # structural
    if re.findall(r'\d+(?:[.,]\d+)*', en) == re.findall(r'\d+(?:[.,]\d+)*', tx):
        ok += 1
        checks += 1
    if ('·' in en) == ('·' in tx):
        ok += 1
        checks += 1
    return ok, checks


rows = []
for i in sorted(tr):
    best = []
    for d in (-2, -1, 0, 1, 2):
        j = i + d
        if j not in src:
            continue
        ok, checks = score(src[j], tr[i])
        best.append((ok / max(1, checks), d, checks))
    best.sort(reverse=True)
    rows.append((i, best[0][1], best[0][0], best[0][2] if len(best[0]) > 2 else 0))

# compress into runs where offset != 0, print all runs of nonzero offset
runs = []
cur = None
for i, d, s, c in rows:
    if cur and cur[0] == d:
        cur[2] = i
        cur[3] += 1
    else:
        if cur:
            runs.append(cur)
        cur = [d, i, i, 1]
if cur:
    runs.append(cur)
print('offset runs (d, from, to, n):')
for r in runs:
    print(r)
