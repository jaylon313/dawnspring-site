﻿import json, io, os
idx = json.load(io.open("_work/en_index.json", encoding="utf-8"))
E = [idx[str(i)]["t"] for i in range(1042)]
mp = {int(k): v for k, v in json.load(io.open("_work/id_align.json", encoding="utf-8")).items()}

FILL = {
 "id": {"63":"Lihat kategori","66":"Lihat kategori","69":"Lihat kategori","72":"Lihat kategori",
        "135":"RMB 1,000,000","184":"Lihat solusinya","267":"Elektronika Konsumen",
        "268":"Minta penawaran","269":"Keluarga produk"},
 "vi": {"63":"Xem danh mục","66":"Xem danh mục","69":"Xem danh mục","72":"Xem danh mục",
        "135":"RMB 1,000,000","184":"Xem giải pháp","267":"Điện tử tiêu dùng",
        "268":"Yêu cầu báo giá","269":"Nhóm sản phẩm"},
}
SPLIT = [(0,260),(261,520),(521,780),(781,1041)]
for lang in ("id","vi"):
    T = {}
    for n in range(1,5):
        T.update(json.load(io.open("_work/%s_part%d.json"%(lang,n), encoding="utf-8")))
    new = {}
    for j, i in mp.items():
        new[i] = T[str(j)]
    for k,v in FILL[lang].items():
        new[int(k)] = v
    assert sorted(new) == list(range(1042)), (len(new), [i for i in range(1042) if i not in new][:5])
    for n,(a,b) in enumerate(SPLIT, 1):
        chunk = {str(i): new[i] for i in range(a, b+1)}
        with io.open("_work/%s_part%d.json"%(lang,n), "w", encoding="utf-8") as f:
            json.dump(chunk, f, ensure_ascii=False, indent=0)
    print(lang, "rekeyed", len(new))
