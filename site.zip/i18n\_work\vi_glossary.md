# Bảng thuật ngữ tiếng Việt (vi) — dùng thống nhất toàn trang

Nguồn: `_work/en_source.tsv` (1042 id). Giọng điệu: B2B trang trọng, văn viết, không cường điệu.

| EN | VI (dùng thống nhất) |
| --- | --- |
| B2B sourcing | thu mua B2B |
| inquiry / send an inquiry | yêu cầu báo giá / gửi yêu cầu báo giá |
| quotation | báo giá (bằng văn bản) |
| Request a quotation | Yêu cầu báo giá |
| MOQ | MOQ (số lượng đặt hàng tối thiểu) — giữ nguyên chữ MOQ |
| lead time | thời gian giao hàng |
| Incoterm / Incoterms | Incoterm / Incoterms |
| EXW / FOB / CIF | EXW / FOB / CIF (không dịch) |
| specification | thông số kỹ thuật |
| datasheet | bảng dữ liệu |
| test report | báo cáo thử nghiệm |
| certificate | chứng nhận |
| certificate of origin | giấy chứng nhận xuất xứ |
| compliance | tuân thủ |
| pre-shipment inspection | kiểm tra trước khi giao hàng |
| consolidation | gom hàng |
| freight forwarder | đơn vị giao nhận vận tải |
| export partner | đối tác xuất khẩu |
| energy storage | lưu trữ năng lượng |
| battery storage / battery | pin lưu trữ / pin |
| Solar PV | điện mặt trời (PV) |
| PV modules | mô-đun PV |
| hybrid inverter | inverter hybrid |
| portable power station | trạm điện di động |
| EV charging | sạc EV |
| residential | nhà ở / dân dụng |
| commercial & industrial (C&I) | thương mại & công nghiệp (C&I) |
| off-grid | ngoài lưới (off-grid) |
| grid code | tiêu chuẩn lưới điện |
| hardware & tools | kim khí & dụng cụ |
| consumer electronics | điện tử tiêu dùng |
| private label | nhãn riêng |
| wholesale | bán buôn |
| buyer | người mua |
| distributor | nhà phân phối |
| EPC contractor | nhà thầu EPC |
| installer | đơn vị lắp đặt |
| lot | lô |
| grade | cấp hạng |
| raw Pu'er (sheng) | Phổ Nhĩ sống (sheng) |
| ripe Pu'er (shou) | Phổ Nhĩ chín (shou) |
| Dianhong | Dianhong |
| arabica | arabica |
| legal name | tên pháp định |
| business scope | phạm vi kinh doanh |
| credit code | mã tín dụng |
| registered capital | vốn đăng ký |
| customs declaration | khai báo hải quan |
| verification / verified | kiểm chứng / đã kiểm chứng |
| available / pending | có sẵn / đang chờ |
| per order / per lot / per supplier | theo đơn hàng / theo lô / theo nhà cung cấp |

Ghi chú: giữ nguyên "Hainan Dawnspring International Trade Co., Ltd." và "DAWNSPRING". Không đổi mã, số, đơn vị (kWh, kW, kWp, V, W), tên tiêu chuẩn (UN38.3, IEC 61215/61730, INMETRO, UL/ETL, FCC, CE/UKCA, RoHS/REACH, ISO), địa chỉ và email.

## v6 增补（见 id_glossary.md 同表）；越南语列：
- Solutions → Giải pháp
- featured programmes → chương trình nổi bật
- sub-modules → mô-đun con
- Jump to → Chuyển đến
- Send us → Gửi cho chúng tôi
- Typical scope → Phạm vi điển hình
- manufacturing clusters → cụm sản xuất
- Feedback → Phản hồi
- notified body → tổ chức được chỉ định
- accredited lab → phòng thử nghiệm được công nhận
- peak shaving → cắt đỉnh phụ tải
- load profile → biểu đồ phụ tải
- BOS → linh kiện BOS
- DAWNSPRING / Dawnspring 与英文法定名保留原文
