import io, json, glob

raw = io.open('_work/en_source.tsv', encoding='utf-8').read().split('\n')
src = {}
for ln in raw:
    if not ln.strip():
        continue
    i, t = ln.split('\t', 1)
    src[int(i)] = t

data = {}
for p in ['_work/pt_merged.json', '_work/pt_chunkA.json', '_work/pt_chunkB.json',
          '_work/pt_chunkC.json', '_work/pt_chunkD.json']:
    d = {int(k): v for k, v in json.load(io.open(p, encoding='utf-8')).items()}
    for k, v in d.items():
        if k in data:
            raise SystemExit('duplicate id %s from %s' % (k, p))
        data[k] = v

missing = [i for i in range(1042) if i not in data]
extra = [i for i in data if i not in range(1042)]
print('count', len(data), 'missing', missing[:20], 'extra', extra[:10])

json.dump({str(k): data[k] for k in sorted(data)}, io.open('_work/pt_all.json', 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('wrote _work/pt_all.json')
