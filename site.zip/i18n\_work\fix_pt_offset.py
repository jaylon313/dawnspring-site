import io, json, glob

lang = 'pt'

raw = io.open('_work/en_source.tsv', encoding='utf-8').read().split('\n')
src = {}
for ln in raw:
    if not ln.strip():
        continue
    i, t = ln.split('\t', 1)
    src[int(i)] = t

data = {}
for p in sorted(glob.glob('_work/%s_part*.json' % lang)):
    for k, v in json.load(io.open(p, encoding='utf-8')).items():
        data[int(k)] = v

# keys 225..599 currently hold translations of src 226..600
new = {}
for k, v in data.items():
    if 225 <= k <= 599:
        new[k + 1] = v
    else:
        new[k] = v

new[225] = 'Tipo, grau, colheita, embalagem, quantidade'

# fix known residue: id 540 stray shift check later
assert 225 in new
print('have', len(new), 'max', max(new))
with io.open('_work/pt_merged.json', 'w', encoding='utf-8') as f:
    json.dump({str(k): new[k] for k in sorted(new)}, f, ensure_ascii=False, indent=1)
missing = [i for i in range(min(new), 601) if i not in new]
print('missing below 601:', missing[:20])
