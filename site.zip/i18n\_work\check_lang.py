"""Validate one or more translated language files against en.json.

Usage: python check_lang.py <lang> [<lang> ...]
"""
import json
import io
import os
import re
import sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TAG = re.compile(r"<[^>]+>")
NUM = re.compile(r"\d[\d,\.]*")


def flat(obj, prefix=""):
    out = {}
    if isinstance(obj, dict):
        for k, v in obj.items():
            out.update(flat(v, prefix + "." + k))
    elif isinstance(obj, str):
        out[prefix] = obj
    return out


def load(name):
    with io.open(os.path.join(BASE, name), encoding="utf-8") as f:
        return json.load(f)


en = flat({k: load("en.json")[k] for k in ("shared", "pages")})
for lang in sys.argv[1:]:
    path = lang + ".json"
    if not os.path.exists(os.path.join(BASE, path)):
        print("%-6s MISSING FILE" % lang)
        continue
    doc = load(path)
    tr = flat({k: doc[k] for k in ("shared", "pages")})
    keys_ok = set(en) == set(tr)
    tag_bad = [k for k in en if sorted(TAG.findall(en[k])) != sorted(TAG.findall(tr[k]))]
    num_bad = [k for k in en if sorted(NUM.findall(en[k])) != sorted(NUM.findall(tr[k]))]
    raw_amp = [k for k, v in tr.items() if re.search(r"&(?![a-zA-Z]+;|#\d+;)", v)]
    same_as_en = [k for k in en if tr.get(k) == en[k]]
    empty = [k for k, v in tr.items() if not v.strip()]
    print(
        "%-6s strings=%d keys_ok=%s status=%s lang=%s tags_bad=%d nums_bad=%d raw_amp=%d same_as_en=%d empty=%d"
        % (lang, len(tr), keys_ok, doc.get("status"), doc.get("language"),
           len(tag_bad), len(num_bad), len(raw_amp), len(same_as_en), len(empty))
    )
    if tag_bad:
        print("   tag examples:", tag_bad[:3])
    if num_bad:
        print("   num examples:", num_bad[:3])
