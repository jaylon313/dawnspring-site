# Glosarium Indonesia (id) — konsistensi istilah

Sumber: `_work/en_source.tsv` (1042 id). Nada: B2B formal, tidak berlebihan.

| EN | ID (dipakai konsisten) |
| --- | --- |
| B2B sourcing | pengadaan B2B |
| inquiry / send an inquiry | permintaan penawaran / kirim permintaan penawaran |
| quotation | penawaran (tertulis) |
| Request a quotation | Minta penawaran |
| MOQ | MOQ (jumlah pesanan minimum) — singkatan MOQ dipertahankan |
| lead time | waktu tunggu |
| Incoterm / Incoterms | Incoterm / Incoterms |
| EXW / FOB / CIF | EXW / FOB / CIF (tidak diterjemahkan) |
| specification | spesifikasi |
| datasheet | lembar data |
| test report | laporan uji |
| certificate | sertifikat |
| certificate of origin | sertifikat asal |
| compliance | kepatuhan |
| pre-shipment inspection | inspeksi pra-pengiriman |
| consolidation | konsolidasi |
| freight forwarder | freight forwarder |
| export partner | mitra ekspor |
| energy storage | penyimpanan energi |
| battery storage / battery | penyimpanan baterai / baterai |
| Solar PV | PLTS (fotovoltaik surya); "PV" dipertahankan bila berdampingan dengan modul/inverter |
| PV modules | modul PV |
| hybrid inverter | inverter hibrida |
| portable power station | pembangkit listrik portabel |
| EV charging | pengisian daya EV |
| residential | hunian |
| commercial & industrial (C&I) | komersial & industri (C&I) |
| off-grid | off-grid (di luar jaringan) |
| grid code | kode grid |
| hardware & tools | perangkat keras & perkakas |
| consumer electronics | elektronika konsumen |
| private label | label privat |
| wholesale | grosir |
| buyer | pembeli |
| distributor | distributor |
| EPC contractor | kontraktor EPC |
| installer | pemasang |
| lot | lot |
| grade | tingkat mutu |
| raw Pu'er (sheng) | Pu'er mentah (sheng) |
| ripe Pu'er (shou) | Pu'er matang (shou) |
| Dianhong | Dianhong |
| arabica | arabika |
| legal name | nama badan hukum |
| business scope | ruang lingkup usaha |
| credit code | kode kredit |
| registered capital | modal terdaftar |
| customs declaration | deklarasi pabean |
| verification / verified | verifikasi / terverifikasi |
| available / pending | tersedia / tertunda |
| per order / per lot / per supplier | per pesanan / per lot / per pemasok |

Catatan: "Hainan Dawnspring International Trade Co., Ltd." tidak diterjemahkan; "DAWNSPRING" dipertahankan. Kode, nomor, satuan (kWh, kW, kWp, V, W), nama model (UN38.3, IEC 61215/61730, INMETRO, UL/ETL, FCC, CE/UKCA, RoHS/REACH, ISO) tidak diubah. Alamat dan email tidak diubah.

## v6 增补（品牌更名 + 新增模块用语）

| EN (v6) | ID | VI |
| --- | --- | --- |
| DAWNSPRING / Dawnspring | DAWNSPRING / Dawnspring（保留） | DAWNSPRING / Dawnspring（保留） |
| Hainan Dawnspring International Trade Co., Ltd. | 保留英文全称 | 保留英文全称 |
| Solutions | Solusi | Giải pháp |
| featured programmes | program unggulan | chương trình nổi bật |
| sub-modules | sub-modul | mô-đun con |
| Jump to | Lompat ke | Chuyển đến |
| Send us | Kirim kepada kami | Gửi cho chúng tôi |
| Typical scope | Lingkup tipikal | Phạm vi điển hình |
| manufacturing clusters | klaster manufaktur | cụm sản xuất |
| Feedback | Masukan | Phản hồi |
| feedback form | formulir masukan | biểu mẫu phản hồi |
| internal only | hanya internal | chỉ nội bộ |
| notified body | notified body（保留） | tổ chức được chỉ định |
| accredited lab | laboratorium terakreditasi | phòng thử nghiệm được công nhận |
| peak shaving | peak shaving（保留） | cắt đỉnh phụ tải |
| load profile | profil beban | biểu đồ phụ tải |
| BOS components | komponen BOS | linh kiện BOS |
| installer kits | kit pemasang | bộ dụng cụ lắp đặt |
| gift packaging | kemasan hadiah | bao bì quà tặng |
