"""Merge translated strings into a language JSON.

Usage:
    python apply.py <lang> <translations.json> [<translations2.json> ...]

- Loads web/i18n/en.json as the structural base.
- Reads web/i18n/_work/en_index.json to map ids -> key paths.
- Each translations file is a flat object { "<id>": "<translated text>" }.
- Writes web/i18n/<lang>.json with language/bcp47/status updated.
- Reports missing ids (kept as English fallback).
"""
import json
import io
import os
import sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WORK = os.path.join(BASE, "_work")

if len(sys.argv) < 3:
    raise SystemExit("usage: python apply.py <lang> <translations.json> [...]")

lang = sys.argv[1]
files = sys.argv[2:]

with io.open(os.path.join(WORK, "en_index.json"), encoding="utf-8") as f:
    index = json.load(f)

merged = {}
for path in files:
    with io.open(path, encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, dict):
        raise SystemExit("not a JSON object: " + path)
    merged.update({str(k): v for k, v in data.items()})

unknown = [k for k in merged if k not in index]
missing = [k for k in index if k not in merged]
if unknown:
    raise SystemExit("unknown ids: %d (first: %s)" % (len(unknown), unknown[:5]))

with io.open(os.path.join(BASE, "en.json"), encoding="utf-8") as f:
    doc = json.load(f)


def set_path(node, path, value):
    cur = node
    for key in path[:-1]:
        cur = cur[key]
    cur[path[-1]] = value


for key, value in merged.items():
    if not isinstance(value, str):
        raise SystemExit("value for id %s is not a string" % key)
    set_path(doc, index[key]["p"], value)

doc["language"] = lang
doc["bcp47"] = {"zh": "zh-CN"}.get(lang, lang)
doc["status"] = "complete"

out = os.path.join(BASE, lang + ".json")
with io.open(out, "w", encoding="utf-8") as f:
    json.dump(doc, f, ensure_ascii=False, indent=1)

print("wrote:", out)
print("translated: %d / %d" % (len(merged), len(index)))
if missing:
    print("MISSING ids: %d (kept English) e.g. %s" % (len(missing), missing[:10]))
